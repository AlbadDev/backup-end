from django.urls import path
from .views import ShowCreateView, ShowListView, ShowDetailView

urlpatterns = [
    path('shows/', ShowListView.as_view(), name='show-list'),
    path('shows/create/', ShowCreateView.as_view(), name='show-create'),
    path('shows/<int:pk>/', ShowDetailView.as_view(), name='show-detail'),
]

