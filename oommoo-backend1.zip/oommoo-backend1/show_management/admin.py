from django.contrib import admin
from .models import Venue, Show, ShowDate, WatchList, Crew, Director, PR_Agent, Producer, Writer

# Register your models here.
admin.site.register(Venue)
admin.site.register(Show)
admin.site.register(ShowDate)
admin.site.register(WatchList)
admin.site.register(Crew)
admin.site.register(Writer)
admin.site.register(Director)
admin.site.register(PR_Agent)
admin.site.register(Producer)


