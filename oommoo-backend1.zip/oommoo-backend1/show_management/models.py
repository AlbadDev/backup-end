from django.db import models
from django.contrib.auth import get_user_model
import datetime
from django.db.models import Avg, FloatField
from django.utils import timezone

User = get_user_model()

class Venue(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class ShowDate(models.Model):
    date = models.DateField(default=datetime.date(year=2024, month=5, day=4))
    time = models.TimeField(default=datetime.time(hour=0, minute=0))
    venue = models.ForeignKey(Venue, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.date} at {self.time} in {self.venue.name}"

class Writer(models.Model):
    name = models.CharField(max_length=100, null=True)
    image = models.URLField(blank=True, null=True)
    def __str__(self):
        return self.name

class Director(models.Model):
    name = models.CharField(max_length=100, null=True)
    image = models.URLField(blank=True, null=True)
    def __str__(self):
        return self.name

class Producer(models.Model):
    name = models.CharField(max_length=100, null=True)
    image = models.URLField(blank=True, null=True)
    def __str__(self):
        return self.name

class PR_Agent(models.Model):
    name = models.CharField(max_length=100, null=True)
    image = models.URLField(blank=True, null=True)
    def __str__(self):
        return self.name

class Crew(models.Model):
    writer = models.ForeignKey(Writer, on_delete=models.CASCADE, null=True)
    director = models.ForeignKey(Director, on_delete=models.CASCADE, null=True)
    producer = models.ForeignKey(Producer, on_delete=models.CASCADE, null=True)
    pR_Agent = models.ForeignKey(PR_Agent, on_delete=models.CASCADE, null=True)

class Show(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    crew = models.ForeignKey(Crew, on_delete=models.CASCADE, null=True)
    title = models.CharField(max_length=100)
    summary = models.TextField()
    dates = models.ManyToManyField(ShowDate)
    duration = models.IntegerField(default=0)
    age_restriction = models.BooleanField(default=False)
    image = models.TextField(blank=True, null=True)
    trailer = models.TextField(blank=True, null=True)
    venue = models.ForeignKey(Venue, on_delete=models.SET_NULL, null=True, blank=True)
    time = models.TimeField(default=datetime.time(hour=0, minute=0))
    slug = models.CharField(max_length=500)
    genre = models.Choices
    
    GENRE_CHOICES = [
        ("Naturalism", "Naturalism"),
        ("Epic Theatre", "Epic Theatre"),
        ("Musical Theatre", "Musical Theatre"),
        ("Comedy", "Comedy"),
        ("Tragedy", "Tragedy"),
        ("Melodrama", "Melodrama"),
        ("Farce", "Farce"),
        ("Physical Theatre", "Physical Theatre"),
        ("Verbatim Theatre", "Verbatim Theatre"),
    ]

    genre = models.CharField(max_length=20, choices=GENRE_CHOICES, default="Naturalism")
    number_of_perfomers = models.IntegerField(default=1)
    website = models.TextField(blank=True, null=True)
    instagram = models.TextField(blank=True, null=True)
    facebook = models.TextField(blank=True, null=True)
    twitter = models.TextField(blank=True, null=True)
    tiktok = models.TextField(blank=True, null=True)
    linkedin = models.TextField(blank=True, null=True)
    average_rating = models.FloatField(default=0)
    ratings_count = models.IntegerField(default=0)

    def __str__(self):
        return self.title
    
    def update_average_rating(self):
        reviews = self.reviews.all()  # Access related reviews using the specified related_name
        avg_rating = reviews.aggregate(avg=Avg('rating', output_field=FloatField()))['avg'] or 0
        self.average_rating = avg_rating
        self.ratings_count = reviews.count()
        self.save()



class WatchList(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    show = models.ForeignKey(Show, on_delete=models.CASCADE)
    added_at = models.DateTimeField(default=timezone.now)

    class Meta:
        unique_together = ('user', 'show')
