from rest_framework import serializers
from .models import Show, ShowDate, Venue, Crew, Writer, Director, Producer, PR_Agent

class VenueSerializer(serializers.ModelSerializer):
    class Meta:
        model = Venue
        fields = ['id', 'name']

class ShowDateSerializer(serializers.ModelSerializer):
    venue = VenueSerializer()

    class Meta:
        model = ShowDate
        fields = ['id', 'date', 'time', 'venue']


class WriterSerializer(serializers.ModelSerializer):
    class Meta:
        model = Writer
        fields = ['id', 'name', 'image']

class DirectorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Director
        fields = ['id', 'name', 'image']

class ProducerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Producer
        fields = ['id', 'name', 'image']

class PRAgentSerializer(serializers.ModelSerializer):
    class Meta:
        model = PR_Agent
        fields = ['id', 'name', 'image']

class CrewSerializer(serializers.ModelSerializer):
    writer = WriterSerializer(read_only=True)
    director = DirectorSerializer(read_only=True)
    producer = ProducerSerializer(read_only=True)
    pR_Agent = PRAgentSerializer(read_only=True)

    class Meta:
        model = Crew
        fields = ['id', 'writer', 'director', 'producer', 'pR_Agent']



class ShowSerializer(serializers.ModelSerializer):
    average_rating = serializers.FloatField(read_only=True)
    ratings_count = serializers.IntegerField(read_only=True)

    class Meta:
        model = Show
        fields = [
            'id', 'title', 'summary', 'slug',
            'image', 'average_rating', 'ratings_count'
        ]

    
class ShowCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Show
        fields = '__all__'