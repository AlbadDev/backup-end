from django.apps import AppConfig


class ShowManagementConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "show_management"
