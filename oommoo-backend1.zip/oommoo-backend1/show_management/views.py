from rest_framework import viewsets, filters
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.pagination import PageNumberPagination
from .models import Show
from .serializers import ShowSerializer, ShowCreateSerializer
from rest_framework import generics
from rest_framework.response import Response
from rest_framework import status

class ShowPagination(PageNumberPagination):
    page_size = 10  
    page_size_query_param = 'page_size'  
    max_page_size = 100  
    


class ShowCreateView(generics.CreateAPIView):
    queryset = Show.objects.all()
    serializer_class = ShowCreateSerializer
class ShowListView(generics.ListAPIView):
    serializer_class = ShowSerializer
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter, filters.SearchFilter]
    filterset_fields = ['dates__venue']
    ordering_fields = ['dates__date', 'slug']  # Ensure 'slug' is a valid ordering field
    search_fields = ['title', 'summary']
    pagination_class = ShowPagination

    def get_queryset(self):
        queryset = Show.objects.all()

        start_date = self.request.query_params.get('start_date', None)
        end_date = self.request.query_params.get('end_date', None)
        venue_id = self.request.query_params.get('venue_id', None)

        if start_date:
            queryset = queryset.filter(dates__date__gte=start_date)
        if end_date:
            queryset = queryset.filter(dates__date__lte=end_date)
        if venue_id:
            queryset = queryset.filter(dates__venue_id=venue_id)
        
        # Apply custom ordering to ensure desired slug ordering
        queryset = queryset.order_by('slug')
        
        return queryset
class ShowDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Show.objects.all()
    serializer_class = ShowSerializer

    def get(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        ratings_data = {
            'average_rating': instance.average_rating,
            'ratings_count': instance.ratings_count,
        }
        serializer_data = serializer.data
        serializer_data.update(ratings_data)
        return Response(serializer_data)
