from django.contrib import admin

from .models import AudienceProfile, IndustryProfile, CustomUser

admin.site.register(AudienceProfile)
admin.site.register(IndustryProfile)
admin.site.register(CustomUser)

