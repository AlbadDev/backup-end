from rest_framework import permissions

class IsOwnerOrAdmin(permissions.BasePermission):
    """
    Custom permission to only allow owners of an object or admin users to view, update or delete it.
    """

    def has_object_permission(self, request, view, obj):
        """
        Check if the requesting user is the owner of the object or is an admin.

        Args:
            request (HttpRequest): The incoming request.
            view (APIView): The view associated with the request.
            obj: The object being accessed.

        Returns:
            bool: True if the user is the owner of the object or is an admin, False otherwise.
        """
        # Allow GET, PUT, PATCH, or DELETE requests if the user is the owner of the object or is an admin
        return obj == request.user or request.user.is_staff
