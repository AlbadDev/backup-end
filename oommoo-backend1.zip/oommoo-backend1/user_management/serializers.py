from rest_framework import serializers

from .models import AudienceProfile, IndustryProfile
from django.conf import settings
from django.contrib.auth import get_user_model
from django.utils.translation import gettext_lazy as _

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError as DjangoValidationError
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError

from rest_framework_simplejwt.tokens import RefreshToken

try:
    from allauth.account import app_settings as allauth_account_settings
    from allauth.account.adapter import get_adapter
    from allauth.account.utils import setup_user_email
    from allauth.utils import email_address_exists, get_username_max_length
except ImportError:
    raise ImportError('allauth needs to be added to INSTALLED_APPS.')


User = get_user_model()

class UserDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = get_user_model()
        fields = ('username', 'first_name', 'last_name', 'email', 'pk')
   
class CustomUserSerializer(serializers.ModelSerializer):
    """
    Serializer for the CustomUser model.
    """
    confirm_password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'age', 'user_type']
        extra_kwargs = {
            'password': {'write_only': True},
            'confirm_password': {'write_only': True}

        }

    def validate(self, data):
        """
        Check if password and confirm_password match.
        """
        if data.get('password') != data.get('confirm_password'):
            raise serializers.ValidationError("Passwords do not match.")
        return data

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        user.set_password(validated_data['password'])
        user.save()
        return user


class AudienceProfileSerializer(serializers.ModelSerializer):
    """
    Serializer for AudienceProfile model.
    """
    class Meta:
        model = AudienceProfile
        fields = '__all__'  


class IndustryProfileSerializer(serializers.ModelSerializer):
    """
    Serializer for IndustryProfile model.
    """
    class Meta:
        model = IndustryProfile
        fields = '__all__'



class RegisterSerializer(serializers.Serializer):
    username = serializers.CharField(
        max_length=get_username_max_length(),
        min_length=allauth_account_settings.USERNAME_MIN_LENGTH,
        required=allauth_account_settings.USERNAME_REQUIRED,
    )
    first_name = serializers.CharField()
    last_name = serializers.CharField()
    email = serializers.EmailField(required=allauth_account_settings.EMAIL_REQUIRED)
    password1 = serializers.CharField(write_only=True)
    password2 = serializers.CharField(write_only=True)
    user_type_choices = [
        "Audience", "Industry"
    ]
    user_type = serializers.ChoiceField(choices=user_type_choices)

    def validate(self, data):
        if data['password1'] != data['password2']:
            raise serializers.ValidationError("Passwords do not match.")
        
        try:
            validate_password(data['password1'])
        except ValidationError as e:
            raise serializers.ValidationError(e.messages)

        return data

    def validate_username(self, username):
        username = get_adapter().clean_username(username)
        return username


    def validate_first_name(self, first_name):
        first_name = get_adapter().clean_username(first_name)
        return first_name
    
    def validate_first_name(self, last_name):
        last_name = get_adapter().clean_username(last_name)
        return last_name

    def validate_email(self, email):
        email = get_adapter().clean_email(email)
        if allauth_account_settings.UNIQUE_EMAIL:
            if email and email_address_exists(email):
                raise serializers.ValidationError(
                    _('A user is already registered with this e-mail address.'),
                )
        return email

    def validate_password1(self, password):
        return get_adapter().clean_password(password)

    def custom_signup(self, request, user):
        pass

    def get_cleaned_data(self):
        return {
            'username': self.validated_data.get('username', ''),
            'password1': self.validated_data.get('password1', ''),
            'password2': self.validated_data.get('password2', ''),
            'email': self.validated_data.get('email', ''),
            'user_type': self.validated_data.get('user_type', 'Audience'),
            'first_name': self.validated_data.get('first_name', ''),
            'last_name': self.validated_data.get('last_name', '')
        }

    def save(self, request):
        adapter = get_adapter()
        user = adapter.new_user(request)
        self.cleaned_data = self.get_cleaned_data()
        user = adapter.save_user(request, user, self, commit=False)
        
        # Set the user_type here
        user.user_type = self.cleaned_data.get('user_type', 'Audience')
        
        if "password1" in self.cleaned_data:
            try:
                adapter.clean_password(self.cleaned_data['password1'], user=user)
            except DjangoValidationError as exc:
                raise serializers.ValidationError(
                    detail=serializers.as_serializer_error(exc)
                )
        user.save()
        self.custom_signup(request, user)
        setup_user_email(request, user, [])
        return user




# ...............
# class SimpleRegisterSerializer(serializers.Serializer):
#     email = serializers.EmailField(required=True)
#     username = serializers.CharField(max_length=150, required=True)

#     def validate_email(self, email):
#         email = get_adapter().clean_email(email)
#         if email and User.objects.filter(email=email).exists():
#             raise serializers.ValidationError('A user is already registered with this email address.')
#         return email

#     def validate_username(self, username):
#         username = get_adapter().clean_username(username)
#         if User.objects.filter(username=username).exists():
#             raise serializers.ValidationError('A user is already registered with this username.')
#         return username

#     def create(self, validated_data):
#         user = User.objects.create(
#             email=validated_data['email'],
#             username=validated_data['username']
#         )
#         return user


    
# from rest_framework import serializers
# from django.contrib.auth.models import User
# from rest_framework_jwt.settings import api_settings
# from allauth.account.adapter import get_adapter
from django.contrib.auth import authenticate

class SimpleRegisterSerializer(serializers.Serializer):
    email = serializers.EmailField(required=True)
    username = serializers.CharField(max_length=150, required=True)

    def validate_email(self, email):
        email = get_adapter().clean_email(email)
        return email

    # def validate_username(self, username):
    #     username = get_adapter().clean_username(username)
    #     return username

    # def validate(self, data):
    #     email = data.get('email')
        # username = data.get('username')
        # user = User.objects.filter(email=email).first()

        # if user:
        #     # User exists, skip username validation
        #     if user.username != username:
        #         raise serializers.ValidationError({'username': 'This username is not associated with the provided email.'})
        # else:
            # User does not exist, proceed with username validation
            # if User.objects.filter(username=username).exists():
            #     raise serializers.ValidationError({'username': 'A user with that username already exists.'})

        # return data

    def create(self, validated_data):
        email = validated_data['email']
        username = validated_data['username']
        user = User.objects.filter(email=email).first()
        
        if user:
            # User exists, authenticate and return JWT token
            refresh = RefreshToken.for_user(user)
            return {
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'user_id': user.pk
            }
        else:
            # User does not exist, create a new user
            user = User.objects.create(
                email=email,
                username=username
            )
            user.set_password('password')  # Set a default password or handle password securely
            user.save()

            # Generate JWT token for the new user
            refresh = RefreshToken.for_user(user)
            return {
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'user_id': user.pk
            }
# Updated View
# python
# Copy code
# from rest_framework.views import 




# class SimpleRegisterSerializer(serializers.Serializer):
#     email = serializers.EmailField(required=True)
#     username = serializers.CharField(max_length=150, required=True)

#     def validate_email(self, email):
#         email = get_adapter().clean_email(email)
#         if email and User.objects.filter(email=email).exists():
#             raise serializers.ValidationError('A user is already registered with this email address.')
#         return email

#     def validate_username(self, username):
#         username = get_adapter().clean_username(username)
#         if User.objects.filter(username=username).exists():
#             raise serializers.ValidationError('A user is already registered with this username.')
#         return username

#     def create(self, validated_data):
#         user = User.objects.create(
#             email=validated_data['email'],
#             username=validated_data['username']
#         )
#         return user