import json
from oommoo.settings import base
from django.http import HttpResponseRedirect
from rest_framework import generics
from rest_framework.generics import RetrieveUpdateAPIView
from rest_framework.permissions import IsAuthenticated
from .models import AudienceProfile, IndustryProfile
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from django.contrib.auth import get_user_model
from django.http import HttpResponseRedirect
from .serializers import (AudienceProfileSerializer, IndustryProfileSerializer, CustomUserSerializer,
                          AudienceProfileSerializer, IndustryProfileSerializer, RegisterSerializer, SimpleRegisterSerializer, UserDetailsSerializer)
from dj_rest_auth.registration.views import RegisterView
from oommoo.settings.base import EMAIL_CONFIRM_REDIRECT_BASE_URL, PASSWORD_RESET_CONFIRM_REDIRECT_BASE_URL
from django.utils.decorators import method_decorator
from django.utils.translation import gettext_lazy as _
from django.views.decorators.debug import sensitive_post_parameters
from django.conf import settings
from rest_framework.permissions import AllowAny
import requests
from rest_framework_simplejwt.tokens import RefreshToken
from django.conf import settings
from django.shortcuts import redirect
from django.views.generic.base import View
from django.views.decorators.csrf import csrf_exempt
from requests import post, get
from django.contrib.auth import authenticate, login, get_backends




User = get_user_model()


def email_confirm_redirect(request, key):
    return HttpResponseRedirect(f"{EMAIL_CONFIRM_REDIRECT_BASE_URL}{key}/")


def password_reset_confirm_redirect(request, uidb64, token):
    return HttpResponseRedirect(
        f"{PASSWORD_RESET_CONFIRM_REDIRECT_BASE_URL}{uidb64}/{token}/"
    )

sensitive_post_parameters_m = method_decorator(
    sensitive_post_parameters(
        'password', 'old_password', 'new_password1', 'new_password2',
    ),
)

User = get_user_model()



class FacebookRedirectURIView(APIView):
    permission_classes = [AllowAny]

    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)

    def get(self, request):
        code = request.GET.get('code')

        if not code:
            return Response({'message': 'Login failed. Authorization code not found in request URL.'}, status=status.HTTP_400_BAD_REQUEST)

        token_response = self.exchange_code_for_token(code)
        if token_response.status_code != 200:
            return Response({'message': 'Login failed. Unable to exchange authorization code for access token.'}, status=status.HTTP_400_BAD_REQUEST)

        facebook_access_token = token_response.json().get('access_token')
        if not facebook_access_token:
            return Response({'message': 'Login failed. Unable to retrieve access token from Facebook response.'}, status=status.HTTP_400_BAD_REQUEST)

        profile_response = self.get_user_profile(facebook_access_token)
        if profile_response.status_code != 200:
            return Response({'message': 'Login failed. Unable to retrieve profile information from Facebook.'}, status=status.HTTP_400_BAD_REQUEST)

        user = self.create_or_get_user(profile_response.json())
        if user is None:
            return Response({'message': 'Login failed. Unable to create or retrieve user.'}, status=status.HTTP_400_BAD_REQUEST)

        # Specify the backend
        backend = 'django.contrib.auth.backends.ModelBackend'
        user.backend = backend
        login(request, user, backend=backend)

        return self.redirect_to_frontend()

    def exchange_code_for_token(self, code):
        token_endpoint = 'https://graph.facebook.com/v12.0/oauth/access_token'
        token_params = {
            'client_id': settings.SOCIAL_AUTH_FACEBOOK_OAUTH2_KEY,
            'client_secret': settings.SOCIAL_AUTH_FACEBOOK_OAUTH2_SECRET,
            'redirect_uri': 'http://127.0.0.1:8000/facebook/callback',
            'code': code,
        }
        return get(token_endpoint, params=token_params)

    def get_user_profile(self, access_token):
        profile_endpoint = 'https://graph.facebook.com/v12.0/me?fields=id,email,first_name,last_name&access_token=' + access_token
        return get(profile_endpoint)

    def create_or_get_user(self, profile_data):
        user, created = User.objects.get_or_create(
            username=profile_data.get("email"),
            defaults={
                'first_name': profile_data.get("first_name"),
                'last_name': profile_data.get("last_name"),
                'email': profile_data.get("email"),
            }
        )
        return user

    def redirect_to_frontend(self):
        frontend_redirect_url = "http://oommoo.xyz"
        response = redirect(frontend_redirect_url)
        response['Access-Control-Allow-Origin'] = '*'
        response['Access-Control-Allow-Credentials'] = 'true'
        return response


class FacebookAuthRedirect(View):
    permission_classes = [AllowAny]
    
    def get(self, request):
        state = "oommoostatettggbb"
        redirect_uri = settings.FACEBOOK_REDIRECT_URI
        redirect_url = f"https://www.facebook.com/v12.0/dialog/oauth?client_id={settings.SOCIAL_AUTH_FACEBOOK_OAUTH2_KEY}&redirect_uri={redirect_uri}&state={state}&scope=email"
        return redirect(redirect_url)


class GoogleRedirectURIView(APIView):
    permission_classes = [AllowAny]

    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)

    def get(self, request):
        code = request.GET.get('code')

        if not code:
            print(f"google code {code}")
            return Response({'message': 'Login failed. Authorization code not found in request URL.'}, status=status.HTTP_400_BAD_REQUEST)

        token_response = self.exchange_code_for_token(code)
        # print(f"google token {token_response}")
        if token_response.status_code != 200:
            return Response({'message': 'Login failed. Unable to exchange authorization code for access token.'}, status=status.HTTP_400_BAD_REQUEST)

        google_access_token = token_response.json().get('access_token')
        # print(f"google access toke {google_access_token}")
        if not google_access_token:
            return Response({'message': 'Login failed. Unable to retrieve access token from \oogle response.'}, status=status.HTTP_400_BAD_REQUEST)

        # Use the Google access token to get your app's access token
        app_token_response = self.exchange_google_token_for_app_token(google_access_token)
        print(f"my app token {app_token_response}")
        if app_token_response.status_code != 200:
            return Response({'message': f'Login failed. Unable to convert Google access token to app access token. {google_access_token}'}, status=status.HTTP_400_BAD_REQUEST)

        app_access_token = app_token_response.json().get('access_token')
        print(f"app access token {app_access_token}")
        refresh_token = app_token_response.json().get('refresh_token')
        print(f"app refresh token {refresh_token}")
        # Send app tokens to frontend via POST request
        self.send_tokens_to_frontend(app_access_token, refresh_token)

        # Redirect to frontend URL
        return self.redirect_to_frontend()

    def exchange_code_for_token(self, code):
        token_endpoint = 'https://oauth2.googleapis.com/token'
        token_params = {
            'code': code,
            'client_id': settings.SOCIAL_AUTH_GOOGLE_OAUTH2_KEY,
            'client_secret': settings.SOCIAL_AUTH_GOOGLE_OAUTH2_SECRET,
            'redirect_uri': settings.GOOGLE_REDIRECT_URI,
            'grant_type': 'authorization_code',
        }
        return post(token_endpoint, data=token_params)

    def exchange_google_token_for_app_token(self, google_access_token):
        convert_token_endpoint = 'http://127.0.0.1:8000/auth/convert-token'
        convert_token_params = {
            'grant_type': 'convert_token',
            'client_id': settings.SOCIAL_AUTH_GOOGLE_OAUTH2_KEY,
            'client_secret': settings.SOCIAL_AUTH_GOOGLE_OAUTH2_SECRET,
            'backend': 'google-oauth2',
            'token': google_access_token,
        }
        return post(convert_token_endpoint, data=convert_token_params)

    def send_tokens_to_frontend(self, access_token, refresh_token):
        frontend_url = "http://127.0.0.1:3000"
        # https://oommoo.xyz
        frontend_data = {
            'access_token': access_token,
            'refresh_token': refresh_token,
        }
        # Example: Post tokens data to frontend endpoint
        post(frontend_url, data=frontend_data)

    def redirect_to_frontend(self):
        frontend_redirect_url = "http://127.0.0.1:3000"
        # https://oommoo.xyz
        response = redirect(frontend_redirect_url)
        response['Access-Control-Allow-Origin'] = '*'
        response['Access-Control-Allow-Credentials'] = 'true'
        return response


class GoogleAuthRedirect(View):
    permission_classes = [AllowAny]
    
    def get(self, request):
        state = "oommoostatettggbb"
        redirect_uri = settings.GOOGLE_REDIRECT_URI
        redirect_url = f"https://accounts.google.com/o/oauth2/v2/auth?client_id={settings.SOCIAL_AUTH_GOOGLE_OAUTH2_KEY}&response_type=code&scope=https://www.googleapis.com/auth/userinfo.profile%20https://www.googleapis.com/auth/userinfo.email&access_type=offline&redirect_uri={redirect_uri}&state={state}"
        return redirect(redirect_url)

class CustomRegisterView(RegisterView):
    """
    API endpoint for user registration.

    This view handles user registration for different account types. It accepts a POST request with user data
    and validates it using a custom serializer. If valid, a new user and a corresponding profile object are created
    using the appropriate serializer based on the user type.
    """

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        print(serializer)
        if serializer.is_valid():
    
            print({serializer})

            user = serializer.save(request)
            user_type = serializer.validated_data.get('user_type')

            profile_data = {}
            if user_type == 'Audience':
                audience_data = request.data.copy()
                audience_data['user'] = user.pk
                profile_serializer = AudienceProfileSerializer(data=audience_data)
                if profile_serializer.is_valid():
                    profile_serializer.save()  # Create profile with user relationship
                    profile_data = profile_serializer.data
                else:
                    return Response(profile_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
            elif user_type == 'Industry':
                audience_data = request.data.copy()
                audience_data['user'] = user.pk
                profile_serializer = IndustryProfileSerializer(data=audience_data)
                if profile_serializer.is_valid():
                    profile_serializer.save()  # Create profile with user relationship
                    profile_data = profile_serializer.data
                else:
                    return Response(profile_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            response_data = {
                'email': user.email,
                'username': user.username,
                'user_type': user_type,
                **profile_data  # Include profile data based on user type
            }
            return Response(response_data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



    
class UserListView(generics.ListAPIView):
    """
    API endpoint to list all users.
    """
    queryset = User.objects.all()
    serializer_class = CustomUserSerializer

class HomePageView(APIView):
    """
    API endpoint to return a message indicating that the user is on the home page.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        """
        Handle GET requests to return the home page message.
        """
        message = "You are on the home page"
        return Response({"message": message})

class AudienceProfileListView(generics.ListAPIView):
    """
    API endpoint to list all audience profiles.
    """
    queryset = AudienceProfile.objects.all()
    serializer_class = AudienceProfileSerializer
    permission_classes = [IsAuthenticated]

class AudienceProfileCreateView(generics.CreateAPIView):
    """
    API endpoint to create a new audience profile.
    """
    queryset = AudienceProfile.objects.all()
    serializer_class = AudienceProfileSerializer

class AudienceProfileDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    API endpoint to retrieve, update, or delete an audience profile instance.
    """
    queryset = AudienceProfile.objects.all()
    serializer_class = AudienceProfileSerializer

class IndustryProfileListView(generics.ListAPIView):
    """
    API endpoint to list all industry profiles.
    """
    queryset = IndustryProfile.objects.all()
    serializer_class = IndustryProfileSerializer

class IndustryProfileCreateView(generics.CreateAPIView):
    """
    API endpoint to create a new industry profile.
    """
    queryset = IndustryProfile.objects.all()
    serializer_class = IndustryProfileSerializer

class IndustryProfileDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    API endpoint to retrieve, update, or delete an industry profile instance.
    """
    queryset = IndustryProfile.objects.all()
    serializer_class = IndustryProfileSerializer


def email_confirm_redirect(request, key):
    return HttpResponseRedirect(
        f"{base.EMAIL_CONFIRM_REDIRECT_BASE_URL}{key}/"
    )


def password_reset_confirm_redirect(request, uidb64, token):
    return HttpResponseRedirect(
        f"{base.PASSWORD_RESET_CONFIRM_REDIRECT_BASE_URL}{uidb64}/{token}/"
    )


class UserDetailsView(RetrieveUpdateAPIView):
    """
    Reads and updates UserModel fields.
    Accepts GET, PUT, PATCH methods.

    Default accepted fields: username, first_name, last_name
    Default display fields: pk, username, email, first_name, last_name
    Read-only fields: pk, email

    Returns UserModel fields.
    """
    serializer_class = UserDetailsSerializer
    permission_classes = (IsAuthenticated,)

    def get_object(self):
        pk = self.kwargs.get('pk')
        if pk:
            return get_user_model().objects.get(id=pk)
 
        

    def get_queryset(self):
        """
        Adding this method since it is sometimes called when using
        django-rest-swagger
        """
        return get_user_model().objects.none()
    



    # ......................

# class CustomRegisterProView(APIView):
#     """
#     API endpoint for simplified user registration using only email and username.
#     """

#     def post(self, request):
#         serializer = SimpleRegisterSerializer(data=request.data)
#         if serializer.is_valid():
#             user = serializer.save()
#             # Print the created user's pk
#             print(f'Created user pk: {user.pk}') 
            
#             # Create JWT token for the new user
#             refresh = RefreshToken.for_user(user)
#             access_token = str(refresh.access_token)

#             response_data = {
#                 'email': user.email,
#                 'username': user.username,
#                 'user_pk': user.pk,
#                 'access_token': access_token,
#                 'refresh_token': str(refresh),
#             }
#             return Response(response_data, status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

class CustomRegisterProView(APIView):
    def post(self, request):
        serializer = SimpleRegisterSerializer(data=request.data)
        if serializer.is_valid():
            result = serializer.save()
            return Response(result, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# # views.py
# from django.http import JsonResponse
# # from django.views import View
# from google.auth.transport.requests import Request
# from google.oauth2 import id_token
# from django.conf import settings

# GOOGLE_CLIENT_ID = '341719446771-017uue501asl9a0p5u76bisdm95a0647.apps.googleusercontent.com'


# class CustomUserView(APIView):
#     def post(self, request):
#         try:
#             body = json.loads(request.body)
#         except ValueError as e:
#             return JsonResponse({'error': 'Invalid JSON'}, status=400)
        
#         access_token = body.get('access_token')
#         if not access_token:
#             return JsonResponse({'error': 'Access token is required'}, status=400)

#         try:
#             id_info = id_token.verify_oauth2_token(access_token, Request(), settings.GOOGLE_CLIENT_ID)
#         except ValueError as e:
#             return JsonResponse({'error': str(e)}, status=400)
        
#         user_data = {
#             'id': id_info.get('sub'),
#             'email': id_info.get('email'),
#             'name': id_info.get('name'),
#             'picture': id_info.get('picture')
#         }
#         return JsonResponse({'user_data': user_data})
    


    # except json.JSONDecodeError:
    #     return JsonResponse({'error': 'Invalid JSON'}, status=400)

# class CustomRegisterProView(APIView):
#     """
#     API endpoint for simplified user registration using only email and username.
#     """

#     def post(self, request):
#         serializer = SimpleRegisterSerializer(data=request.data)
#         if serializer.is_valid():
#             response_data = serializer.save()
#             return Response(response_data, status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)









# class ConvertTokenView(APIView):
#     def post(self, request):
#         provider_token = request.data.get('provider_token')
#         backend = request.data.get('backend')  # e.g., 'google-oauth2', 'facebook', etc.
       
#         if not provider_token or not backend:
#             return Response({"error": "Provider token and backend are required."}, status=status.HTTP_400_BAD_REQUEST)

#         data = {
#             'grant_type': 'convert_token',
#             'client_id': settings.SOCIAL_AUTH_GOOGLE_OAUTH2_KEY,
#             'client_secret': settings.SOCIAL_AUTH_GOOGLE_OAUTH2_SECRET,
#             'backend': backend,
#             'token': provider_token,
#         }
#         print(data)
#         response = requests.post('http://127.0.0.1:8000/auth/convert-token', data=data)

#         if response.status_code == 200:
#             return Response(response.json())
#         else:
#             return Response(response.json(), status=response.status_code)

# class ConvertTokenView(APIView):
#     def post(self, request):
#         provider_token = request.data.get('provider_token')
#         backend = request.data.get('backend')  # e.g., 'google-oauth2', 'facebook', etc.
       
#         if not provider_token or not backend:
#             return Response({"error": "Provider token and backend are required."}, status=status.HTTP_400_BAD_REQUEST)

#         data = {
#             'grant_type': 'convert_token',
#             'client_id': settings.SOCIAL_AUTH_GOOGLE_OAUTH2_KEY,
#             'client_secret': settings.SOCIAL_AUTH_GOOGLE_OAUTH2_SECRET,
#             'backend': backend,
#             'token': provider_token,
#         }
#         print(data)
        
#         # try: 
#         #     response = requests.post('http://127.0.0.1:8000/auth/convert-token', data=data)
#         #     response.raise_for_status()  # Raise an HTTPError for bad responses (4xx and 5xx)
#         # except requests.exceptions.RequestException as e:
#         #     return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
#         # try:
#         #     response_data = response.json()
#         # except ValueError:
#         #     return Response({"error": "Invalid JSON response from server."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#         # return Response(response_data, status=response.status_code)



# class CustomRegisterProView(APIView):
#     """
#     API endpoint for simplified user registration using only email and username.
#     """

#     def post(self, request):
#         serializer = SimpleRegisterSerializer(data=request.data)
#         if serializer.is_valid():
#             user = serializer.save()
#             # Print the created user's pk
#             print(f'Created user pk: {user.pk}')
#             response_data = {
#                 'email': user.email,
#                 'username': user.username,
#                 'user_pk': user.pk
#             }
#             return Response(response_data, status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)