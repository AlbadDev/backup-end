from dj_rest_auth.registration.views import ResendEmailVerificationView, VerifyEmailView
from dj_rest_auth.views import  (LogoutView, PasswordResetConfirmView, PasswordResetView,
                                LoginView)
from django.urls import path

from .views import (  CustomRegisterProView,  email_confirm_redirect, password_reset_confirm_redirect, 
                                  CustomRegisterView, UserDetailsView, UserListView, AudienceProfileCreateView,
            AudienceProfileDetailView, AudienceProfileListView, IndustryProfileCreateView, IndustryProfileDetailView,
            HomePageView, GoogleAuthRedirect, GoogleRedirectURIView)

urlpatterns = [
    path("register/", CustomRegisterView.as_view(), name="rest_register"),
    # ...
    # path('custom-user/', CustomUserView.as_view(), name='custom-user'),
    path("getin/", CustomRegisterProView.as_view(), name="rest_getin"),
    # path('social-register/', ConvertTokenView.as_view(), name='convert-token'),
    # ...
    path("register/verify-email/", VerifyEmailView.as_view(), name="rest_verify_email"),
    path("register/resend-email/", ResendEmailVerificationView.as_view(), name="rest_resend_email"),
    path("account-confirm-email/<str:key>/", email_confirm_redirect, name="account_confirm_email"),
    path("account-confirm-email/", VerifyEmailView.as_view(), name="account_email_verification_sent"),
    path("password/reset/", PasswordResetView.as_view(), name="rest_password_reset"),
    path(
        "password/reset/confirm/<str:uidb64>/<str:token>/",
        password_reset_confirm_redirect,
        name="password_reset_confirm",
    ),
    path("password/reset/confirm/", PasswordResetConfirmView.as_view(), name="password_reset_confirm"),
    path("login/", LoginView.as_view(), name="rest_login"),
    path("logout/", LogoutView.as_view(), name="rest_logout"),
    path("user/<int:pk>/", UserDetailsView.as_view(), name="rest_user_details"),
    path("users/", UserListView.as_view(), name="list_users"),
    path("audience/profile/", AudienceProfileDetailView.as_view(), name="audience_profile"),
    path("list/audience/profiles/", AudienceProfileListView.as_view(), name="list_audience_profiles"),
    path("audience/profile/create", AudienceProfileCreateView.as_view(), name="create_audience_profile"),
    path("industry/profile/", IndustryProfileDetailView.as_view(), name="industry_profile"),
    path("industry/profile/create/", IndustryProfileCreateView.as_view(), name="create_industry_profile"),
    path("", HomePageView.as_view(), name="home"),
    path("google-signup/", GoogleAuthRedirect.as_view(), name="google-sign"),
    path("google/callback", GoogleRedirectURIView.as_view(), name="google-callback"),


]
