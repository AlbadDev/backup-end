import boto3
from .base import *
import json





# ............................................................................................................................
# .............SETUP GETTING ENV SECRET VARIABLE FROM AWS START HERE ...............................
# .............................................................................................

GOOGLE_REDIRECT_URI = "http://127.0.0.1:8000/google/callback"
FACEBOOK_REDIRECT_URI = "https://server.oommoo.xyz//facebook/callback"

def get_secret(secret_name):
    AWS_DEFAULT_REGION = 'eu-west-2'
    client = boto3.client('secretsmanager', region_name=AWS_DEFAULT_REGION)  # Specify the region

    try:
        response = client.get_secret_value(SecretId=secret_name)
        secret_string = response.get('SecretString', None)

        if secret_string:
            secret_dict = json.loads(secret_string)
            return secret_dict
        else:
            print("SecretString not found in the response")
            return None
    except Exception as e:
        print(f"Error retrieving secret: {e}")
        return None

# Usage example
secret_name = 'db_secret_store'
retrieved_secret = get_secret(secret_name)

if retrieved_secret:

     DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': retrieved_secret.get("db_name"),
        'USER': retrieved_secret.get("db_user"),
        'PASSWORD': retrieved_secret.get("db_pass"),
        'HOST': retrieved_secret.get("db_host"),
        'PORT': retrieved_secret.get("db_port"),      # default PostgreSQL port
    }
     }

else:
    print("Secret retrieval failed.")


# GOOGLE_REDIRECT_URI = "http://127.0.0.1:8000/google/callback"
# FACEBOOK_REDIRECT_URI = "https://server.oommoo.xyz/facebook/callback"

# .............................................................................................
# .............SETUP GETTING ENV SECRET VARIABLE FROM AWS END HERE ...............................
# .......................................................................................................