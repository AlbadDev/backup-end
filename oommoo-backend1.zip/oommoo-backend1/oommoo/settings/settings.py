


ALLOWED_HOSTS = ['*','localhost', '35.179.15.165']