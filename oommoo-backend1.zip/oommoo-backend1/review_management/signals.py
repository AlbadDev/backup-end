from django.db.models.signals import post_save
from django.dispatch import receiver
from review_management.models import Review

@receiver(post_save, sender=Review)
def update_show_average_rating(sender, instance, created, **kwargs):
    """
    Signal handler function to update the average rating of the related Show instance
    when a new review is created.
    """
    if created:
        show = instance.show
        show.update_average_rating()
# review_management/signals.py

from django.db.models.signals import post_save
from django.dispatch import receiver
from review_management.models import Review

@receiver(post_save, sender=Review)
def update_show_average_rating(sender, instance, created, **kwargs):
    """
    Signal handler function to update the average rating of the related Show instance
    when a new review is created.
    """
    if created:
        show = instance.show
        show.update_average_rating()
