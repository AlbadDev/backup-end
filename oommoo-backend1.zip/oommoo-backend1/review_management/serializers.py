from rest_framework import serializers
from review_management.models import Review
from django.contrib.auth import get_user_model
from show_management.models import Show

User = get_user_model()

class ReviewSerializer(serializers.ModelSerializer):
    user_id = serializers.PrimaryKeyRelatedField(source='user.id', read_only=True)
    first_name = serializers.CharField(source='user.first_name', read_only=True)
    last_name = serializers.CharField(source='user.last_name', read_only=True)
    user = serializers.PrimaryKeyRelatedField(queryset=User.objects.all(), write_only=True)
    show_slug = serializers.CharField(write_only=True)
    show = serializers.CharField(source='show.title', read_only=True)  # To show the title of the show in responses

    class Meta:
        model = Review
        fields = ['id', 'user_id', 'first_name', 'last_name', 'user', 'show_slug', 'show', 'review_content', 'created_at', 'category', 'rating']
        read_only_fields = ['created_at']

    def create(self, validated_data):
        show_slug = validated_data.pop('show_slug')
        user = validated_data['user']

        # Retrieve or create the show based on the show slug
        show = Show.objects.filter(slug=show_slug).first()
        if not show:
            raise serializers.ValidationError("Show with this slug does not exist.")
        validated_data['show'] = show
        
        return super().create(validated_data)

    def validate(self, data):
        user = data['user']
        show_slug = data['show_slug']
        show = Show.objects.filter(slug=show_slug).first()

        if show and Review.objects.filter(user=user, show=show).exists():
            raise serializers.ValidationError("You have already reviewed this show.")
        return data