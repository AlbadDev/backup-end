from rest_framework.permissions import IsAuthenticated, IsAdminUser
from .models import Review
from show_management.models import Show
from rest_framework import generics, status
from .serializers import ReviewSerializer
from rest_framework.pagination import PageNumberPagination
from rest_framework.decorators import api_view,permission_classes
from rest_framework.response import Response
from review_management.models import Review

from django.http import JsonResponse


def get_show_by_id_or_slug(slug_or_id):
    """
    Utility function to fetch a show by its ID or slug.
    """
    try:
        show_id = int(slug_or_id)
        return Show.objects.get(id=show_id)
    except (ValueError, Show.DoesNotExist):
        try:
            return Show.objects.get(slug=slug_or_id)
        except Show.DoesNotExist:
            return None  # Return None if show is not found
        
    
class CustomPagination(PageNumberPagination):
    """
    Custom pagination class to paginate review results.
    """
    page_size = 10
    page_size_query_param = 'page_size'
    max_page_size = 100

class AllShowReviewsView(generics.ListAPIView):
    serializer_class = ReviewSerializer

    def get_queryset(self):
        show_slug_or_id = self.kwargs.get('slug_or_id')
        show = get_show_by_id_or_slug(show_slug_or_id)
        if show:
            return Review.objects.filter(show=show)
        return Review.objects.none()

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        if not queryset.exists():
            return Response([], status=status.HTTP_200_OK)  # Return 200 OK with an empty list
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)
    



@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_review(request):
    """
    Function-based view for creating a new review.
    """
    if request.method == 'POST':
        serializer = ReviewSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class RetrieveUpdateDestroyReviewView(generics.RetrieveUpdateDestroyAPIView):
    """
    View for retrieving, updating, and deleting a review by its ID
    """
    queryset = Review.objects.all()
    serializer_class = ReviewSerializer


class ListShowReviewsView(generics.ListAPIView):
    """
    View for listing reviews for a specific show by its ID or slug.
    """
    serializer_class = ReviewSerializer

    def get_queryset(self):
        """
        Returns queryset filtered by the show identifier (ID or slug).
        """
        show_slug = self.request.query_params.get('show_slug')
        if show_slug:
            show = Show.objects.filter(slug=show_slug).first()
            if show:
                return Review.objects.filter(show=show)
        return Review.objects.none() 

    def list(self, request, *args, **kwargs):
        """
        Override the list method to handle cases where show identifier is not provided or no reviews are found.
        """
        queryset = self.get_queryset()
        
        if not queryset.exists():
            return Response(
                {"detail": "No reviews found for the specified show."},
                status=status.HTTP_404_NOT_FOUND
            )
        
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


class ListUserReviewsView(generics.ListAPIView):
    """
    View for listing reviews submitted by a specific user.
    """
    serializer_class = ReviewSerializer

    def get_queryset(self):
        """
        Returns queryset filtered by the user ID.
        """
        user_id = self.request.query_params.get('user_id')
        if user_id:
            return Review.objects.filter(user_id=user_id)
        return Review.objects.none()  

    def get_serializer_context(self):
        """
        Additional context data for serializer.
        """
        context = super().get_serializer_context()
        context['include_user_info'] = True  # Include user information in the serialized output
        return context


class DeleteShowReviewsView(generics.DestroyAPIView):
    """
    View for deleting reviews of a specific show by its ID or slug.
    """
    permission_classes = [IsAdminUser]
    def delete(self, request, slug_or_id, *args, **kwargs):
        show = get_show_by_id_or_slug(slug_or_id)
        
        if not show:
            return JsonResponse({'error': 'Show not found'}, status=status.HTTP_404_NOT_FOUND)
        
        reviews_deleted = Review.objects.filter(show=show).delete()
        num_reviews_deleted = reviews_deleted[0] if reviews_deleted else 0
        
        return Response(
            {"detail": f"{num_reviews_deleted} reviews deleted for the show."},
            status=status.HTTP_200_OK
        )
