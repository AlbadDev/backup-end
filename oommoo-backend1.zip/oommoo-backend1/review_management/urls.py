from django.urls import path
from .views import (
    RetrieveUpdateDestroyReviewView,
    ListShowReviewsView,
    ListUserReviewsView,AllShowReviewsView
)
from .views import create_review

urlpatterns = [
    path('reviews/', create_review, name='create_review'),
    path('reviews/<int:pk>/', RetrieveUpdateDestroyReviewView.as_view(), name='review_detail'),
    path('reviews/show/', ListShowReviewsView.as_view(), name='list_show_reviews'),
    path('reviews/user/', ListUserReviewsView.as_view(), name='list_user_reviews'),
    path('shows/<slug_or_id>/reviews/', AllShowReviewsView.as_view(), name='all-show-reviews'),

]
