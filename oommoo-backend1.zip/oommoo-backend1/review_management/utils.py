from django.db.models import Avg
from show_management.models import Show

from django.shortcuts import get_object_or_404
from review_management.models import Review
from show_management.models import Show
from django.contrib.auth import get_user_model
from django.core.exceptions import ObjectDoesNotExist


User = get_user_model()

def get_reviews_by_user_type(show_slug_or_id, user_type):
    """
    Retrieve reviews for a specific show based on user type.

    Args:
        show_slug_or_id (str): The slug or ID of the show.
        user_type (str): The type of user ('Audience' or 'Industry').

    Returns:
        QuerySet: A queryset of reviews filtered by show and user type, or an empty queryset if there are no reviews.
    """
 
    try:
        # Check if the value is an integer (ID) or a string (slug)
        if show_slug_or_id.isdigit():
            # Query by ID if it's a number
            show = get_object_or_404(Show, id=show_slug_or_id)
        else:
            # Query by slug if it's not a number
            show = get_object_or_404(Show, slug=show_slug_or_id)


        if user_type == 'Audience':
            reviews = Review.objects.filter(show=show, user__user_type='Audience')
        elif user_type == 'Industry':
            reviews = Review.objects.filter(show=show, user__user_type='Industry')
        else:
            raise ValueError(f"Invalid user type: {user_type}")

        return reviews

    except Show.DoesNotExist:
        raise ObjectDoesNotExist(f"No show found with ID or slug: {show_slug_or_id}")
    except Exception as e:
        raise Exception(f"Error retrieving reviews: {e}")


def add_show_methods():
    def average_rating(self):
        ratings = self.ratings.all()
        if ratings.exists():
            return ratings.aggregate(Avg('rating'))['rating__avg']
        return 0

    def ratings_count(self):
        return self.ratings.count()

    def get_ratings(self):
        return self.ratings.all()

    Show.add_to_class('average_rating', average_rating)
    Show.add_to_class('ratings_count', ratings_count)
    Show.add_to_class('get_ratings', get_ratings)

# Call the function to add the methods to the Show model
add_show_methods()
