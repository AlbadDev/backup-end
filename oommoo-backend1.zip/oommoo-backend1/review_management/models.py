# review_management/models.py

from django.db import models
from django.contrib.auth import get_user_model


User = get_user_model()
class RatingChoices(models.IntegerChoices):
    ONE = 1
    TWO = 2
    THREE = 3
    FOUR = 4
    FIVE = 5

    __empty__ = 'Unknown'

class Review(models.Model):
    CATEGORY_CHOICES = (
        ('ALL', 'All'),
        ('VENUE', 'Venue'),
        ('PERFORMANCE', 'Performance'),
    )

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    show = models.ForeignKey("show_management.Show", on_delete=models.CASCADE, related_name='reviews')  # Changed related_name
    review_content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    rating = models.FloatField(null=True, blank=True, choices=RatingChoices.choices)

    def __str__(self):
        return f"Review by {self.user} for {self.show}"
