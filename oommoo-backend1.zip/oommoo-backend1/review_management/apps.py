# review_management/apps.py

from django.apps import AppConfig

class ReviewManagementConfig(AppConfig):
    name = 'review_management'

    def ready(self):
        # Import and connect the signal handler function
        from . import signals  # Ensure that the signals are imported here to connect them
