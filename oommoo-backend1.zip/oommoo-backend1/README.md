
## Installation

# Clone the Repository
```bash
 git clone https://github.com/oommoo-xyz/oommoo-backend.git
```

# cd into the project directory
```bash
  cd oommoo-backend
```

# Install Dependencies
```bash
  pip install -r requirements.txt
```

# create a .env file and add the following variables
```bash
  SECRET_KEY
  EMAIL_HOST_USER
  EMAIL_HOST_PASSWORD
  SOCIAL_AUTH_GOOGLE_OAUTH2_KEY
  SOCIAL_AUTH_GOOGLE_OAUTH2_SECRET
  SOCIAL_AUTH_FACEBOOK_KEY
  SOCIAL_AUTH_FACEBOOK_SECRET
```

# run migrations
```bash
  python3 manage.py makemigrations
  python3 manage.py migrate
```
# run the server 
```bash
  python manage.py runserver
```

# test
