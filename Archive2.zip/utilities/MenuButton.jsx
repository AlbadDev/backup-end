"use client"
import React, {useContext} from 'react';
import Avatar from '@mui/material/Avatar';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import style from '../styles/Navbar.module.scss';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import Tooltip from '@mui/material/Tooltip';
import SettingsIcon from '@mui/icons-material/Settings';
import LogoutIcon from '@mui/icons-material/Logout';
import Link from 'next/link';
import axios from 'axios';
import { useRouter } from 'next/navigation';
import Cookies from 'universal-cookie';
import makeRequest from './makeRequest';
import { UserContext } from '@/lib/ContextApi/UserContext';
import SubscriptionsIcon from '@mui/icons-material/Subscriptions';
import ListIcon from '@mui/icons-material/List';
import { signOut } from 'next-auth/react';


const AccountMenu = () => {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const [selected, setSelected] = React.useState('Dashboard');
    const router = useRouter()
    const open = Boolean(anchorEl);

    const { userData, setUserData } = useContext(UserContext);
    // cokkie
    const cookies = new Cookies();

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    // function LogoutButton() {
    //     const handleLogout = () => {
    //       signOut({
    //         callbackUrl: 'http://localhost:3000/' // Customize the URL to redirect after logout
    //       });
    //     };
      
    //     return (
    //       <button onClick={handleLogout}>Sign out</button>
    //     );
    //   }

    const handleLogout = () => {
        signOut({
          callbackUrl: 'http://localhost:3000/' // Customize the URL to redirect after logout
        })
        cookies.remove("loggedInUserAccessToken")
        cookies.remove("userPK")
      };
      
    //   export default LogoutButton;

    const HandleLogOut = async() => {

        try {
            const response = await makeRequest.post('/logout/').then( () => {
                cookies.remove("loggedInUserAccessToken")
                cookies.remove("userPK")
                return window.location.reload()

            })
       
        } catch (error) {
            console.error('An error occurred:', error);
        }
        
    };





    return (
        <React.Fragment>
            <div style={{display:'flex',justifyContent:'center',alignItems:'center',marginTop:'-10px'}}>
                <Tooltip title="Account settings" >
                    <IconButton 
                        onClick={handleClick}
                        size="small"
                        sx={{ ml: 0 }}
                        aria-controls={open ? 'account-menu' : undefined}
                        aria-haspopup="true"
                        aria-expanded={open ? 'true' : undefined}
                    >
                        <Avatar
                            sx={{
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                                gap:1,
                                width: 122,
                                height: 42,
                                backgroundColor: 'transparent',
                                // color: '#70d8db',
                                border: '1px solid #fff',
                                borderRadius:'20px',
                                padding: '10px 20px',
                            }}

                        //   className={style.IconContainer}ManageAccountsIcon
                        >
                            <ListIcon className={style.logoUser} />
                            <span style={{color:'#fff',fontSize:'14px',fontWeight:'bold'}}>{userData.username}</span>
                        </Avatar> 
                    </IconButton>
                    
                </Tooltip>
            </div>
            <Menu
                anchorEl={anchorEl}
                id="account-menu"
                open={open}
                onClose={handleClose}
                onClick={handleClose}
                PaperProps={{
                    elevation: 0,
                    sx: {
                        overflow: 'visible',
                        filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
                        mt:  0.5,
                        '& .MuiAvatar-root': {
                            width: 32,
                            height: 32,
                            ml: -0.3,
                            mr: 1,
                        },
                        '&::before': {
                            content: '""',
                            display: 'block',
                            position: 'absolute',
                            top: 0,
                            right: 14,
                            width: 10,
                            height: 10,
                            bgcolor: 'background.paper',
                            transform: 'translateY(-50%) rotate(45deg)',
                            zIndex: 0,
                        },
                    },
                }}
                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            >
                <Link href="/profile" className={style.linkHref}>
                    <MenuItem onClick={handleClose} className={style.iconContainer}>
                        <Avatar /> My account
                    </MenuItem>
                </Link>
                <Divider />
                <Link href="/settings" className={style.linkHref}>
                    <MenuItem onClick={handleClose} style={{ display: 'flex', justifyContent: 'center', gap: '10px' }}>
                        <SettingsIcon style={{ color: 'gray' }} /> Settings
                    </MenuItem>
                </Link>

                <Link href="/watchlist" className={style.linkHref} >
                    <MenuItem onClick={handleClose} style={{ display: 'flex', justifyContent: 'center', gap: '10px' }}>
                        <SubscriptionsIcon style={{ color: 'gray' }} /> Watchlist 
                    </MenuItem>
                </Link>
                {/* */}
                {/* <Item title="Settings" to="/changePass" icon={<SettingsIcon />} selected={selected} setSelected={setSelected} /> */}
                <MenuItem onClick={handleLogout}>
                    {/*HandleLogOut  */}
                    <ListItemIcon>
                        <LogoutIcon fontSize="small" />
                    </ListItemIcon>
                    Logout
                </MenuItem>
            </Menu>
        </React.Fragment>
    );
};

export default AccountMenu;
