export const domainName = "https://server.oommoo.xyz";
// export const domainName = "http://127.0.0.1:8000";https://server.oommoo.xyz
