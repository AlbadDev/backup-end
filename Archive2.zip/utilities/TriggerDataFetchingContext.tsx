"use client"
import { Dispatch, SetStateAction, createContext } from "react";

const TriggerDataFetchingContext = createContext<{
    triggerDataFetching: number;
    setTriggerDataFetching: Dispatch<SetStateAction<number>>;
  }>({
    triggerDataFetching: 0,
    setTriggerDataFetching: () => {}
  });

export default TriggerDataFetchingContext;