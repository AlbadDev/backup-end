export function truncateText(text: string, numberOfChar: number): string {
  if (text.length > numberOfChar) {
    let truncatedText = text.slice(0, numberOfChar);
    return `${truncatedText}...`;
  } else {
    return text;
  }
}
