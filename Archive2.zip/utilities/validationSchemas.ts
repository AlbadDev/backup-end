import { z } from "zod";
export const loginSchema = z.object({
  email: z
    .string()
    .min(1, { message: "Email field has to be filled" })
    .max(254)
    .email("This is not a valid email"),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .max(128, "Password must be at most 50 characters"),
});

export const createAudienceAccountSchema = z
  .object({
    firstName: z
      .string()
      .min(2, "First name must contain at least 2 characters")
      .max(50),
    lastName: z
      .string()
      .min(2, "Last name must contain at least 2 characters")
      .max(50),
    email: z
      .string()
      .min(1, { message: "This field has to be filled" })
      .max(254)
      .email("This is not a valid email"),
    password1: z
      .string()
      .min(8, "Password must be at least 8 characters")
      .max(128, "Password must be at most 50 characters"),
    confirmPassword: z
      .string()
      .min(8, " Confirm Password must be at least 8 characters")
      .max(128, "Confirm Password must be at most 50 characters"),
    age: z.string(),
    location: z.string(),
  })
  .refine((data) => data.location !== "", {
    message: "select your location",
    path: ["location"],
  })
  .refine((data) => parseInt(data.age) >= 13, {
    message: "Age must be 13+",
    path: ["age"],
  })
  .refine((data) => data.password1 === data.confirmPassword, {
    message: "Passwords must match",
    path: ["confirmPassword"],
  });

export const createIndustryAccountSchema = z
  .object({
    companyName: z
      .string()
      .min(1, "Company Name must contain at least 1 characters")
      .max(50),
    companyLocation: z.string(),
    contactName: z
      .string()
      .min(2, "Contact Name must contain at least 2 characters")
      .max(50),
    contactEmail: z
      .string()
      .min(1, { message: "Email field has to be filled" })
      .max(254)
      .email("This is not a valid email"),
    contactPhoneNumber: z.string(),
    password1: z
      .string()
      .min(8, "Password must be at least 8 characters")
      .max(128, "Password must be at most 50 characters"),
    confirmPassword: z
      .string()
      .min(8, "Confirm Password must be at least 8 characters")
      .max(128, "Confirm Password must be at most 50 characters"),
  })
  .refine((data) => data.companyLocation !== "", {
    message: "select your location",
    path: ["companyLocation"],
  })
  .refine((data) => data.contactPhoneNumber !== "", {
    message: "Enter your age",
    path: ["contactPhoneNumber"],
  })
  .refine((data) => data.password1 === data.confirmPassword, {
    message: "Passwords must match",
    path: ["confirmPassword"],
  });
