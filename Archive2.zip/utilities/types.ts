export interface LoginInputTypes {
  email: string;
  password: string;
}

export interface AudienceSignUpInputTypes {
  firstName: string;
  lastName: string;
  email: string;
  password1: string;
  confirmPassword: string;
  age: string;
  location: string;
}

export interface IndustrySignUpInputTypes {
  companyName: string;
  companyLocation: string;
  contactName: string;
  contactEmail: string;
  contactPhoneNumber: string;
  password1: string;
  confirmPassword: string;
}

export type Review = {id: number, category: string, created_at: string, first_name: string, last_name: string, rating: number, review_content: string, show: string, user_id: number}