import axios from 'axios'
import Cookies from "universal-cookie";

const cookies = new Cookies();

export const makeRequest = axios.create({
    baseURL: "https://server.oommoo.xyz",
    headers: {
        Authorization: `Bearer ${cookies.get(
          "loggedInUserAccessToken"
        )}`,
        'Content-Type': 'application/json'
      },
        // withCredentials: true,http://127.0.0.1:8000
        // credentials: 'include',
        // credentials: true,
        // crossDomain: true,        
})
export default makeRequest