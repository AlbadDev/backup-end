"use client"
import React, { createContext, useState } from "react";

export const TokenAccessContext = createContext();

export const TokenContextProvider = ({ children }) => {
  const [userAccess, setUserAccess] = useState({ access: false });

  return (
    <TokenAccessContext.Provider value={{ userAccess, setUserAccess }}>
      {children}
    </TokenAccessContext.Provider>
  );
};

export default TokenContextProvider;
