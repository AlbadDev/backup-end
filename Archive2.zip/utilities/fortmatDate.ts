export function formatDate(dateString: string) {
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  // Parse the input date string to a Date object
  const date = new Date(dateString);

  // Get the day, month, and year components
  const day = String(date.getUTCDate()).padStart(2, "0");
  const month = monthNames[date.getUTCMonth()]; // Get month name from array
  const year = date.getUTCFullYear(); // Get the full year

  // Combine the components into the desired format
  return `${day}-${month}-${year}`;
}
