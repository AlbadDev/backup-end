import axios from "axios";
import { domainName } from "./domainName";
import { Dispatch, SetStateAction } from "react";

export async function userAccountRegistration(
  data: any,
  setModalState: any,
  setIsCreatingAccount: Dispatch<SetStateAction<boolean>>,
  setEmailBackendErrorMsg: Dispatch<SetStateAction<string>>,
  setPasswordBackendErrorMsg: Dispatch<SetStateAction<string>>
) {
  setIsCreatingAccount(true);
  axios
    .post(`${domainName}/register/`, data)
    .then((response: any) => {
      setIsCreatingAccount(false);
      setModalState({ isOpen: false });
    })
    .catch((error: any) => {
      if (error?.response?.data?.email !== undefined) {
        setEmailBackendErrorMsg(error?.response?.data?.email[0]);
        setIsCreatingAccount(false);
      } else {
        setEmailBackendErrorMsg("");
      }
      if (error?.response?.data?.non_field_errors) {
        setPasswordBackendErrorMsg(error.response.data.non_field_errors);
        setIsCreatingAccount(false);
      }else{
        setPasswordBackendErrorMsg('')
      }
        if (error?.response?.data?.password1[0]) {
        setPasswordBackendErrorMsg(error.response.data.password1[0]);
        setIsCreatingAccount(false);
      }else{
        setPasswordBackendErrorMsg('');
      }
    });
}