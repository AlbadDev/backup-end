
import { authConfig } from "@/app/api/auth/[...nextauth]/route";
import { getServerSession } from "next-auth";
import Cookies from "universal-cookie";





export async function getCookies(){

  const sessionData = await getServerSession(authConfig)

  // const cookies = new Cookies();
  // let resCookie = await cookies.get("loggedInUserAccessToken")

  // return resCookie
  return sessionData

}