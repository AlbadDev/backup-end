"use client"
import {
  Dispatch,
  Fragment,
  SetStateAction,
  useContext,
  useState,
} from "react";
import { Tab } from "@headlessui/react";
import { ResetCurrentHighlightedAccountContext, UserSelectedAccountToCreate } from "./AuthenticationModal";
import CircularCheckMark from "@/svgs/CircularCheckMark";
import Minus from "@/svgs/Minus";

export default function AudienceIndustryButton({
  currentHighlightedAccount,
  setCurrentHighlightedAccount,
}: {
  currentHighlightedAccount: string
  setCurrentHighlightedAccount: Dispatch<SetStateAction<string>>;
}) {
  const ResetCurrentHighlightedAccount = useContext(
    ResetCurrentHighlightedAccountContext
  );

    const userSelectedAccountToCreate = useContext(UserSelectedAccountToCreate)
  return (
    <Tab.Group
      selectedIndex={
        ResetCurrentHighlightedAccount?.resetCurrentHighlightedAccount
          ? 0
          : undefined
      }
    >
      <Tab.List className="flex items-center justify-between md:justify-evenly md:w-full lg:justify-between lg:w-[132%] xl:justify-evenly xl:w-full mb-[6%] max-[500px]:w-full [500px]:w-[132%]">
        <Tab as={Fragment}>
          {({ selected }) => (
            <button
              className={`${
                selected ? "bg-[#656565] text-white" : "bg-[#D9D9D9] text-black"
              } px-5 py-2 rounded-full font-semibold text-sm outline-none max-sm:py-2 max-sm:px-3 max-sm:text-sm`}
              onClick={() => {
                userSelectedAccountToCreate?.setSelectedAccount('audience')
                setCurrentHighlightedAccount("audience");
              }}
            >
              Audience
            </button>
          )}
        </Tab>
        <Tab as={Fragment}>
          {({ selected }) => (
            <button
              className={`
              ${
                selected ? "bg-[#656565] text-white" : "bg-[#D9D9D9] text-black"
              } 

              px-5 py-2 rounded-full font-semibold ml-[2.5vw] text-sm outline-none max-sm:py-2 max-sm:px-3 max-sm:text-sm`}
              onClick={() => {
                userSelectedAccountToCreate?.setSelectedAccount('industry')
                setCurrentHighlightedAccount("industry");
              }}
            >
              Company
            </button>
          )}
        </Tab>
      </Tab.List>
      <Tab.Panels
        className={
          "flex w-full justify-between max-md:justify-evenly max-[500px]:justify-evenly md:justify-evenly lg:justify-between xl:justify-evenly"
        }
      >
        <Tab.Panels>
          <div>
            <div>
              <CircularCheckMark
                currentHighlightedAccount={currentHighlightedAccount}
                checkMarkAccountType="audience"
              />
            </div>
            <div>
              <CircularCheckMark
                currentHighlightedAccount={currentHighlightedAccount}
                checkMarkAccountType="audience"
              />
            </div>
            <div>
              <CircularCheckMark
                currentHighlightedAccount={currentHighlightedAccount}
                checkMarkAccountType="audience"
              />
            </div>
            <div>
              <Minus />
            </div>
            <div>
              <Minus />
            </div>
            <div>
              <Minus />
            </div>
            <div>
              <Minus />
            </div>
            <div>
              <Minus />
            </div>
          </div>
        </Tab.Panels>
        <Tab.Panels className={"border-r-2 border-black"}></Tab.Panels>

        <Tab.Panels>
          <div>
            <div>
              <CircularCheckMark
                currentHighlightedAccount={currentHighlightedAccount}
                checkMarkAccountType="industry"
              />
            </div>
            <div>
              <CircularCheckMark
                currentHighlightedAccount={currentHighlightedAccount}
                checkMarkAccountType="industry"
              />
            </div>
            <div>
              <CircularCheckMark
                currentHighlightedAccount={currentHighlightedAccount}
                checkMarkAccountType="industry"
              />
            </div>
            <div>
              <CircularCheckMark
                currentHighlightedAccount={currentHighlightedAccount}
                checkMarkAccountType="industry"
              />
            </div>
            <div>
              <CircularCheckMark
                currentHighlightedAccount={currentHighlightedAccount}
                checkMarkAccountType="industry"
              />
            </div>
            <div>
              <CircularCheckMark
                currentHighlightedAccount={currentHighlightedAccount}
                checkMarkAccountType="industry"
              />
            </div>
            <div>
              <CircularCheckMark
                currentHighlightedAccount={currentHighlightedAccount}
                checkMarkAccountType="industry"
              />
            </div>
            <div>
              <CircularCheckMark
                currentHighlightedAccount={currentHighlightedAccount}
                checkMarkAccountType="industry"
              />
            </div>
          </div>
        </Tab.Panels>
      </Tab.Panels>
    </Tab.Group>
  );
}
