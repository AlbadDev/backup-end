"use client"
import React, { useContext } from "react";
import AudienceSignUp from "./AudienceSignUp";
import IndustrySignUp from "./IndustrySignUp";
import { UserSelectedAccountToCreate } from "./AuthenticationModal";

function AccountRegistrationFormModal() {
  const userSelectedAccountToCreate = useContext(UserSelectedAccountToCreate)
  if(userSelectedAccountToCreate?.selectedAccount === 'industry'){
    return (
      <IndustrySignUp /> 
    )
  }
  return (
      <AudienceSignUp />
  );
}

export default AccountRegistrationFormModal;
