"use client"
import CircularCheckMark from "@/svgs/CircularCheckMark";
import "@/components/authentication/auth-modal-styles/auth-modal-styles.css";
import Minus from "@/svgs/Minus";
import AudienceIndustryButton from "./AudienceIndustryButton";
import { Button } from "../ui/button";
import { useContext, useState } from "react";
import {
  AuthModalSliderContext,
  ResetCurrentHighlightedAccountContext,
  UserSelectedAccountToCreate,
} from "./AuthenticationModal";

function AudienceIndustryAccount() {
  const setAuthModalSlider = useContext(AuthModalSliderContext);
  const ResetCurrentHighlightedAccount = useContext(
    ResetCurrentHighlightedAccountContext
  );
  const [currentHighlightedAccount, setCurrentHighlightedAccount] =
    useState("audience");
    const userSelectedAccountToCreate = useContext(UserSelectedAccountToCreate)


  return (
    <div className="hide-scroll-bar overflow-y-scroll w-full max-sm:pl-[10%] max-[400px]:pr-[6%] max-md:pl-[13%] max-md:pr-[2.2%] sm:pl-[12%] sm:pr-[3%] max-h-max  max-sm:pt-3">
      <div className="flex">
        <div className=" w-full self-center justify-between h-full mt-16">
          <p className="pb-5 max-[500px]:pb-5 text-nowrap max-[500px]:text-sm">
            Show rating
          </p>
          <p className="pb-5 max-[500px]:pb-5 text-nowrap max-[500px]:text-sm">
            User profile
          </p>
          <p className="pb-5 max-[500px]:pb-5 text-nowrap max-[500px]:text-sm">
            Comment features
          </p>
          <p className="pb-5 max-[500px]:pb-5 text-nowrap max-[500px]:text-sm">
            Diversity filter
          </p>
          <p className="pb-5 max-[500px]:pb-5 text-nowrap max-[500px]:text-sm">
            Create pages
          </p>
          <p className="pb-5 max-[500px]:pb-5 text-nowrap max-[500px]:text-sm">
            User rating metric
          </p>
          <p className="pb-5 max-[500px]:pb-5 text-nowrap max-[500px]:text-sm">
            Diversity metric
          </p>
          <p className="pb-5 max-sm:pb-5 text-nowrap max-sm:text-sm">
            Dashboard
          </p>
        </div>
        <div className="flex items-center flex-col">
          <AudienceIndustryButton
            currentHighlightedAccount={currentHighlightedAccount}
            setCurrentHighlightedAccount={setCurrentHighlightedAccount}
          />
        </div>
      </div>

      <div className="flex items-center ml-auto mr-auto w-[78%] md:w-[100%] max-md:w-[90%] max-sm:w-full justify-between mt-5 xl:w-full">
        <div className="flex items-center w-full">
          <p className="text-[13px] text-gray-600 text-nowrap">
            Already a member?
          </p>
          <button
            className="font-bold text-[15px] ml-1 text-nowrap"
            onClick={() => {
              userSelectedAccountToCreate?.setSelectedAccount('audience')
              setAuthModalSlider?.setAuthModalSlider("translate-x-0");
              setCurrentHighlightedAccount("audience");
              ResetCurrentHighlightedAccount?.setResetCurrentHighlightedAccount(
                true
              );
            }}
          >
            Log in
          </button>
        </div>
        <Button
          onClick={() => {
            setAuthModalSlider?.setAuthModalSlider("-translate-x-[70.5%]");
          }}
                    className="max-sm:ml-3 rounded-full max-sm:px-3 max-sm:py-3 max-sm:text-xs px-8 py-3 bg-[#1D9FFF] hover:bg-blue-500 font-semibold"

        >
          Create Account
        </Button>
      </div>
    </div>
  );
}

export default AudienceIndustryAccount;
