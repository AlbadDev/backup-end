"use client"
import React, {
  Dispatch,
  SetStateAction,
  createContext,
  useState,
} from "react";
import AudienceIndustryAccount from "./AudienceIndustryAccount";
import Login from "./Login";
import { useBodyScrollLock } from "../../../utilities/lockscroll";
import "@/components/authentication/auth-modal-styles/auth-modal-styles.css";
import AccountRegistrationFormModal from "../authentication/AccountRegistrationFormModal";
import IndustrySignUp from "./IndustrySignUp";
import AudienceSignUp from "./AudienceSignUp";

export const AuthModalSliderContext = createContext<null | {
  setAuthModalSlider: React.Dispatch<React.SetStateAction<string>>;
}>(null);

export const ResetCurrentHighlightedAccountContext = createContext<null | {
  resetCurrentHighlightedAccount: undefined | boolean;
  setResetCurrentHighlightedAccount: React.Dispatch<
    React.SetStateAction<undefined | boolean>
  >;
}>(null);

export const UserSelectedAccountToCreate = createContext<null | {
  selectedAccount: undefined | string;
  setSelectedAccount: React.Dispatch<React.SetStateAction<string>>;
}>(null);
function AuthenticationModal() {
  useBodyScrollLock();
  const [authModalSlider, setAuthModalSlider] = useState("translate-x-0");
  const [resetCurrentHighlightedAccount, setResetCurrentHighlightedAccount] =
    useState<undefined | boolean>(undefined);
  const [selectedAccount, setSelectedAccount] = useState("audience");

  return (
    <div className="md:w-[63vw] md:left-[18.5vw] xl:w-[42vw] xl:left-[27.5vw] hide-scroll-bar max-[280px]:h-[27rem] max-[280px]:w-[90vw] max-[280px]:left-[5vw] max-md:w-[85vw] max-md:left-[7.5vw] bg-white max-sm:h-[75vh] h-[85vh] fixed top-[8vh] left-[25vw] max-sm:left-[5vw] max-sm:w-[90vw] w-[50vw] rounded-xl py-3 max-sm:px-3 pr-14 pl-3 z-30 overflow-hidden">
      <div
        className={`flex items-center w-[342%] ${authModalSlider} transition-transform h-full`}
      >
        <AuthModalSliderContext.Provider
          value={{ setAuthModalSlider: setAuthModalSlider }}
        >
          <ResetCurrentHighlightedAccountContext.Provider
            value={{
              resetCurrentHighlightedAccount,
              setResetCurrentHighlightedAccount,
            }}
          >
            <UserSelectedAccountToCreate.Provider
              value={{ selectedAccount, setSelectedAccount }}
            >
              <Login />
              <AudienceIndustryAccount />
              <AccountRegistrationFormModal />
            </UserSelectedAccountToCreate.Provider>
          </ResetCurrentHighlightedAccountContext.Provider>
        </AuthModalSliderContext.Provider>
      </div>
    </div>
  );
}

export default AuthenticationModal;
