"use client";
import EyeSlash from "@/svgs/EyeSlash";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import SelectGender from "./SelectGender";
import { nanoid } from "nanoid";

import {
  Dispatch,
  SetStateAction,
  useContext,
  useEffect,
  useState,
} from "react";
import Eye from "@/svgs/Eye";
import SelectProfilePicture from "./SelectProfilePicture";
import { useForm, SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { AudienceSignUpInputTypes } from "../../../utilities/types";
import { createAudienceAccountSchema } from "../../../utilities/validationSchemas";
import "@/components/authentication/auth-modal-styles/auth-modal-styles.css";
import { domainName } from "../../../utilities/domainName";
import axios from "axios";
import { LoginModalContext } from "@/lib/loginModalContext";
import { Loader2 } from "lucide-react";
import { userAccountRegistration } from "../../../utilities/userAccountCreation";


function AudienceSignUp() {
  const {
    register,
    handleSubmit,
    getValues,
    setValue,
    formState: { errors },
  } = useForm<AudienceSignUpInputTypes>({
    resolver: zodResolver(createAudienceAccountSchema),
  });
  const [emailBackendErrorMsg, setEmailBackendErrorMsg] = useState("");
  const [passwordBackendErrorMsg, setPasswordBackendErrorMsg] = useState("");
  const { modalState, setModalState } = useContext(LoginModalContext);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [selectedMale, setSelectedMale] = useState(false);
  const [selectedFemale, setSelectedFemale] = useState(false);
  const [checkboxErrorMsg, setCheckboxErrorMsg] = useState(false);
  const [confirmPasswordErrorMsg, setConfirmPasswordErrorMsg] = useState<
    string | undefined
  >("");
  const [isCreatingAccount, setIsCreatingAccount] = useState(false);
  useEffect(() => {
    if (selectedMale || selectedFemale) {
      setCheckboxErrorMsg(false);
    }
  }, [selectedMale, selectedFemale]);
  const onSubmit: SubmitHandler<AudienceSignUpInputTypes> = (data) => {
    if (selectedMale === false && selectedFemale === false) {
      setCheckboxErrorMsg(true);
    } else {
      userAccountRegistration(
        {
          ...data,
          age: Number(data.age),
          user_type: "Audience",
          password1: data.password1,
          password2: data.confirmPassword,
          first_name: data.firstName,
          last_name: data.lastName,
          profile_picture:
            "https://s3-alpha-sig.figma.com/img/ca99/b2b1/253ae1335bda53c7d96cbf37d2d6cf81?Expires=1717977600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=QKEhQObf2vhKKt5BGhlArOHfH5JnBE-h5LiQ4m~o2pC~XBhJSb3ycdJVcchwSiNMJJFMdT6ywkFc5RbY0thJSp3FIxUshuWBAiaiHU7XB4XHdaq79tdznZc1oSRJ2DAk0UMx4yLmIzTQI9bugAtHLcKQQpR1gKRyoALCP7Rpi7ItPvPPpxKazCoyPs0Sm6E5WtZwG9nwKmJ5asPP2sjd9bYwcwH8bGcUq4MOSL8TqW0ac-696aIfcOwn6WkzbiKUQOkTOG6utpCNFB187GAPVuaYdhLn6Y0CUr6xSmpG3RYyIy6qqv36dMT0JLHaM11K37DtGpxpzm9bTiogwOec-Q__",
          gender: selectedMale ? "M" : "F",
          is_active: true,
          is_staff: false,
          is_superuser: false,
          username: `${data.firstName}${nanoid()}`,
        },
        setModalState,
        setIsCreatingAccount,
        setEmailBackendErrorMsg,
        setPasswordBackendErrorMsg
      );
    }
  };

  useEffect(() => {
    if (
      getValues().password1 &&
      getValues().confirmPassword &&
      getValues().password1 === getValues().confirmPassword
    ) {
      setConfirmPasswordErrorMsg("");
    } else if (
      getValues().password1 &&
      getValues().confirmPassword &&
      getValues().password1 !== getValues().confirmPassword
    ) {
      setConfirmPasswordErrorMsg("Passwords do not match");
    }
  }, [
    errors.confirmPassword?.message,
    getValues,
    getValues().password1,
    getValues().confirmPassword,
  ]);

  return (
 <div className="w-full h-full hide-scroll-bar overflow-y-scroll ml-[6%] mb-2">
      <p className="text-4xl font-thin italic text-center text-gray-800">
        Sign up Audience account
      </p>
      <div className="mt-8">
        <form onSubmit={handleSubmit(onSubmit)} noValidate>
          {/* <div>
            <SelectProfilePicture />
            <p className="font-bold text-[12px] text-center mt-2">
              Upload Profile Picture
            </p>
          </div> */}
          <div className="mt-1">
            <label>First Name</label>
            <Input
              placeholder="First Name"
              className=" rounded-full mt-1 text-[12px] border-black border-[0.5px]"
              type="text"
              {...register("firstName")}
            />
            {errors.firstName && (
              <p className="errors">{errors.firstName?.message}</p>
            )}
          </div>
          <div className="mt-6">
            <label>Last Name</label>
            <Input
              placeholder="Last Name"
              className=" rounded-full mt-1 text-[12px] border-black border-[0.5px]"
              type="text"
              {...register("lastName")}
            />
            {errors.lastName && (
              <p className="errors">{errors.lastName?.message}</p>
            )}
          </div>
          <div className="mt-6">
            <label>Email Address</label>
            <Input
              placeholder="Email Address"
              className=" rounded-full mt-1 text-[12px] border-black border-[0.5px]"
              type="email"
              {...register("email")}
            />
            {errors.email && <p className="errors">{errors.email?.message}</p>}
            {emailBackendErrorMsg && (
              <p className="errors">{emailBackendErrorMsg}</p>
            )}
          </div>
          <div className="mt-6">
            <label>Password</label>
            <div className="border-black border-[0.5px] mt-1 rounded-full flex items-center">
              <Input
                placeholder="Password"
                className=" rounded-full text-[12px] border-none"
                type={`${showPassword ? "text" : "password"}`}
                {...register("password1")}
              />
              <button
                className="mr-4"
                onClick={() => {
                  setShowPassword((showPassword) => !showPassword);
                }}
                type="button"
              >
                {showPassword ? <Eye /> : <EyeSlash />}
              </button>
            </div>
            {errors.password1 && (
              <p className="errors">{errors.password1?.message}</p>
            )}
            {passwordBackendErrorMsg && (
              <p className="errors">{passwordBackendErrorMsg}</p>
            )}
          </div>
          <div className="mt-6">
            <label>Confirm Password</label>
            <div className="border-black border-[0.5px] mt-1 rounded-full flex items-center">
              <Input
                placeholder="Confirm Password"
                className=" rounded-full text-[12px] border-none"
                type={`${showConfirmPassword ? "text" : "password"}`}
                {...register("confirmPassword")}
              />
              <button
                className="mr-4"
                onClick={() => {
                  setShowConfirmPassword(
                    (showConfirmPassword) => !showConfirmPassword
                  );
                }}
                type="button"
              >
                {showConfirmPassword ? <Eye /> : <EyeSlash />}
              </button>
            </div>

            {errors.confirmPassword && (
              <p className="errors">{errors.confirmPassword?.message}</p>
            )}
          </div>
          <div className="mt-6">
            <label>Age</label>
            <Input
              placeholder="Age"
              className=" rounded-full mt-1 text-[12px] border-black border-[0.5px]"
              type="number"
              {...register("age")}
              onChange={(e: any) =>
                setValue("age", e.target.value, {
                  shouldValidate: true,
                })
              }
              min={1}
            />
            {errors.age && <p className="errors">{errors.age?.message}</p>}
          </div>
          <div className="mt-6">
            <label>Gender</label>
            <SelectGender
              selectedMale={selectedMale}
              selectedFemale={selectedFemale}
              setSelectedMale={setSelectedMale}
              setSelectedFemale={setSelectedFemale}
            />
            {checkboxErrorMsg && <p className="errors">select a gender</p>}
          </div>
          <div className="mt-6 flex flex-col">
            <label>Location</label>
            <Input
              placeholder="Location"
              className=" rounded-full mt-1 text-[12px] border-black border-[0.5px]"
              type="text"
              {...register("location")}
            />

            {errors.location && (
              <p className="errors">{errors.location?.message}</p>
            )}
          </div>
          <div className="w-[50%] mx-auto mt-7">
            <Button
              onClick={() => {
                if (selectedMale === false && selectedFemale === false) {
                  setCheckboxErrorMsg(true);
                }
              }}
              className="rounded-full w-full py-3 bg-[#1D9FFF]  hover:bg-blue-500 font-semibold"
            >
              {isCreatingAccount ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  <p>Creating an account...</p>
                </>
              ) : (
                <p>Create Audience account</p>
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
export default AudienceSignUp;
