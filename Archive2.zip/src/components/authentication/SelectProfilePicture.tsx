import Dropzone from "react-dropzone";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";

function SelectProfilePicture() {
  return (
    <Dropzone onDrop={(acceptedFiles) => console.log(acceptedFiles)}>
      {({ getRootProps, getInputProps }) => (
        <div className="mt-6 w-16 h-16 mx-auto rounded-full">
          <div {...getRootProps()} className="h-full">
            {/* <input {...getInputProps()} /> */}
            <Avatar className="w-full h-full mx-auto cursor-pointer">
              <AvatarImage
                src="https://github.com/shadcn.png"
                alt="profile pic"
              />
              <AvatarFallback className="p-2">CN</AvatarFallback>
            </Avatar>
          </div>
        </div>
      )}
    </Dropzone>
  );
}

export default SelectProfilePicture;
