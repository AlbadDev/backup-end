"use client";
import EyeSlash from "@/svgs/EyeSlash";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import SelectGender from "./SelectGender";
import SelectLocation from "./SelectLocation";
import { useContext, useEffect, useState } from "react";
import Eye from "@/svgs/Eye";
import SelectProfilePicture from "./SelectProfilePicture";
import YesNoCheckBoxes from "./YesNoCheckBoxes";
import { SubmitHandler, useForm } from "react-hook-form";
import { IndustrySignUpInputTypes } from "../../../utilities/types";
import { createIndustryAccountSchema } from "../../../utilities/validationSchemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { userAccountRegistration } from "../../../utilities/userAccountCreation";
import { LoginModalContext } from "@/lib/loginModalContext";


function IndustrySignUp() {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [selectedYes, setSelectedYes] = useState(false);
  const [selectedNo, setSelectedNo] = useState(false);
  const [checkboxErrorMsg, setCheckboxErrorMsg] = useState(false);
  const [isCreatingAccount, setIsCreatingAccount] = useState(false);
  const [emailBackendErrorMsg, setEmailBackendErrorMsg] = useState("");
  const { modalState, setModalState } = useContext(LoginModalContext);
  const [passwordBackendErrorMsg, setPasswordBackendErrorMsg] = useState("");
  const [confirmPasswordErrorMsg, setConfirmPasswordErrorMsg] = useState<
    string | undefined
  >("");
  const {
    register,
    handleSubmit,
    getValues,
    setValue,
    formState: { errors },
  } = useForm<IndustrySignUpInputTypes>({
    resolver: zodResolver(createIndustryAccountSchema),
  });
  const onSubmit: SubmitHandler<IndustrySignUpInputTypes> = (data) => {
    if (selectedYes === false && selectedNo === false) {
      setCheckboxErrorMsg(true);
    } else {
      userAccountRegistration(
        {
          ...data,
          company_location: data.companyLocation,
          company_name: data.companyName,
          contact_email: data.contactEmail,
          contact_name: data.contactName,
          contact_phone_number: data.contactPhoneNumber,
          email:data.contactEmail,
          password2: data.confirmPassword,
          user_type: "Industry",
          // profile_picture:
          //   "https://s3-alpha-sig.figma.com/img/ca99/b2b1/253ae1335bda53c7d96cbf37d2d6cf81?Expires=1717977600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=QKEhQObf2vhKKt5BGhlArOHfH5JnBE-h5LiQ4m~o2pC~XBhJSb3ycdJVcchwSiNMJJFMdT6ywkFc5RbY0thJSp3FIxUshuWBAiaiHU7XB4XHdaq79tdznZc1oSRJ2DAk0UMx4yLmIzTQI9bugAtHLcKQQpR1gKRyoALCP7Rpi7ItPvPPpxKazCoyPs0Sm6E5WtZwG9nwKmJ5asPP2sjd9bYwcwH8bGcUq4MOSL8TqW0ac-696aIfcOwn6WkzbiKUQOkTOG6utpCNFB187GAPVuaYdhLn6Y0CUr6xSmpG3RYyIy6qqv36dMT0JLHaM11K37DtGpxpzm9bTiogwOec-Q__",
          is_active: true,
          is_staff: false,
          is_superuser: false,
        },
        setModalState,
        setIsCreatingAccount,
        setEmailBackendErrorMsg,
        setPasswordBackendErrorMsg
      );
    }
  };
  useEffect(() => {
    if (selectedYes || selectedNo) {
      setCheckboxErrorMsg(false);
    }
  }, [selectedYes, selectedNo]);
  useEffect(() => {
    setConfirmPasswordErrorMsg(errors.confirmPassword?.message);
    if (
      getValues().password1 &&
      getValues().confirmPassword &&
      getValues().password1 === getValues().confirmPassword
    ) {
      setConfirmPasswordErrorMsg("");
    }
  }, [
    errors.confirmPassword?.message,
    getValues,
    // getValues().password,
    // getValues().confirmPassword,
  ]);

  return (
<div className="w-full h-full hide-scroll-bar overflow-y-scroll ml-[6%] mb-2">
      <p className="text-4xl font-thin italic text-center text-gray-800">
        Sign up Company account
      </p>
      <div className="mt-8">
        <form onSubmit={handleSubmit(onSubmit)} noValidate>
          {/* <div>
            <SelectProfilePicture />
            <p className="font-bold text-[12px] text-center mt-2">
              Upload Profile Picture
            </p>
          </div> */}
          <div className="mt-1">
            <label>Company Name</label>
            <Input
              placeholder="Enter Name"
              className=" rounded-full mt-1 text-[12px] border-black border-[0.5px]"
              type="text"
              {...register("companyName")}
            />
            {errors.companyName && (
              <p className="errors">{errors.companyName?.message}</p>
            )}
          </div>
          <div className="mt-6 flex flex-col">
            <label>Company Location</label>
            <Input
              placeholder="Select Company Location"
              className=" rounded-full mt-1 text-[12px] border-black border-[0.5px]"
              type="text"
              { ...register("companyLocation")}
            />
            {errors.companyLocation && (
              <p className="errors">{errors.companyLocation?.message}</p>
            )}
          </div>
          <div className="mt-6">
            <label>Contact Name</label>
            <Input
              placeholder="Enter Name"
              className=" rounded-full mt-1 text-[12px] border-black border-[0.5px]"
              type="text"
              {...register("contactName")}
            />
            {errors.contactName && (
              <p className="errors">{errors.contactName?.message}</p>
            )}
          </div>
          <div className="mt-6">
            <label>Contact Email</label>
            <Input
              placeholder="Email Address"
              className=" rounded-full mt-1 text-[12px] border-black border-[0.5px]"
              type="email"
              {...register("contactEmail")}
            />
            {errors.contactEmail && (
              <p className="errors">{errors.contactEmail?.message}</p>
            )}
            {emailBackendErrorMsg && (
              <p className="errors">{emailBackendErrorMsg}</p>
            )}
          </div>
          <div className="mt-6">
            <label>Contact Phone Number</label>
            <Input
              placeholder="Enter Number"
              className=" rounded-full mt-1 text-[12px] border-black border-[0.5px]"
              type="number"
              {...register("contactPhoneNumber")}
              onChange={(e: any) =>
                setValue("contactPhoneNumber", e.target.value, {
                  shouldValidate: true,
                })
              }
            />
            {errors.contactPhoneNumber && (
              <p className="errors">{errors.contactPhoneNumber?.message}</p>
            )}
          </div>
          <div className="mt-6">
            <label>Password</label>
            <div className="border-black border-[0.5px] mt-1 rounded-full flex items-center">
              <Input
                placeholder="Password"
                className=" rounded-full text-[12px] border-none"
                type={`${showPassword ? "text" : "password"}`}
                {...register("password1")}
              />
              <button
                className="mr-4"
                onClick={() => {
                  setShowPassword((showPassword) => !showPassword);
                }}
                type="button"
              >
                {showPassword ? <Eye /> : <EyeSlash />}
              </button>
            </div>
          </div>
           {passwordBackendErrorMsg && (
              <p className="errors">{passwordBackendErrorMsg}</p>
            )}
          {errors.password1 && (
            <p className="errors">{errors.password1?.message}</p>
          )}
          <div className="mt-6">
            <label>Confirm Password</label>
            <div className="border-black border-[0.5px] mt-1 rounded-full flex items-center">
              <Input
                placeholder="Confirm Password"
                className=" rounded-full text-[12px] border-none"
                type={`${showConfirmPassword ? "text" : "password"}`}
                {...register("confirmPassword")}
              />
              <button
                className="mr-4"
                onClick={() => {
                  setShowConfirmPassword(
                    (showConfirmPassword) => !showConfirmPassword
                  );
                }}
                type="button"
              >
                {showConfirmPassword ? <Eye /> : <EyeSlash />}
              </button>
            </div>
          </div>
          {confirmPasswordErrorMsg && (
            <p className="errors">{confirmPasswordErrorMsg}</p>
          )}
          <div className="mt-6">
            <label>Do you currently have a show you want to list?</label>
            <YesNoCheckBoxes
              selectedYes={selectedYes}
              selectedNo={selectedNo}
              setSelectedYes={setSelectedYes}
              setSelectedNo={setSelectedNo}
            />
            {checkboxErrorMsg && <p className="errors">select an option</p>}
          </div>
          <div className="mt-3">
            <p className="text-sm">
              (If yes, proceed to show listing format here)
            </p>
          </div>
          <div className="w-[50%] mx-auto mt-7">
            <Button
              onClick={() => {
                if (selectedYes === false && selectedNo === false) {
                  setCheckboxErrorMsg(true);
                }
              }}
              className="rounded-full w-full py-3 bg-[#1D9FFF]  hover:bg-blue-500 font-semibold"
            >
              Create Company account
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default IndustrySignUp;
