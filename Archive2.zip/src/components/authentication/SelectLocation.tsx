import "@/components/authentication/auth-modal-styles/auth-modal-styles.css";
import { regionAndCountyUnitary } from "../../../utilities/regionAndCountyUnitary";
function SelectLocation({ registerLocation }: { registerLocation: any }) {
  return (
    <select
      {...registerLocation}
      id="location"
      className="cursor-pointer w-full rounded-full text-[15px] border-black border-[0.5px] outline-none pl-3 pr-8 py-2 h-10 mt-1"
    >
      <option value="" hidden>
        select an option
      </option>
      {regionAndCountyUnitary.map((location, index) => {
        return (
          <option
            key={index}
            value={`${location.region}: ${location.county_unitary}`}
          >
            {location.region}: {location.county_unitary}
          </option>
        );
      })}
      {/* <option value="2">2</option>
      <option value="3">3</option>
      <option value="ksdjf">ksddk</option>
      <option value="ksdjf">ksddk</option>
      <option value="ksdjf">ksddk</option>
      <option value="ksdjf">ksddk</option>
      <option value="ksdjf">ksddk</option>
      <option value="ksdjf">ksddk</option>
      <option value="ksdjf">ksddk</option>
      <option value="ksdjf">ksddk</option>
      <option value="ksdjf">ksddk</option>
      <option value="ksdjf">ksddk</option>
      <option value="ksdjf">ksddk</option>
      <option value="ksdjf">ksddk</option>
      <option value="ksdjf">ksddk</option>
      <option value="ksdjf">ksddk</option>
      <option value="ksdjf">ksddk</option> */}
    </select>
  );
}

export default SelectLocation;
