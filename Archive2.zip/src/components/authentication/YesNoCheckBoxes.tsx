"use client";
import { Dispatch, SetStateAction, useState } from "react";
import { Checkbox } from "../ui/checkbox";

function YesNoCheckBoxes({
  selectedYes,
  selectedNo,
  setSelectedYes,
  setSelectedNo,
}: {
  selectedYes: boolean;
  selectedNo: boolean;
  setSelectedYes: Dispatch<SetStateAction<boolean>>;
  setSelectedNo: Dispatch<SetStateAction<boolean>>;
}) {
  return (
    <div className="flex items-center justify-between w-[30%]">
      <div className="flex items-center">
        <input
          type="checkbox"
          checked={selectedYes}
          onChange={(e) => {
            setSelectedNo(false);
            if (selectedYes === true) {
              setSelectedYes(true);
            } else {
              setSelectedYes(e.target.checked);
            }
          }}
          className="w-4 h-4 cursor-pointer"
        />
        <label className="ml-1 text-[15px]">Yes</label>
      </div>
      <div className="flex items-center">
        <input
          type="checkbox"
          checked={selectedNo}
          onChange={(e) => {
            setSelectedYes(false);
            if (selectedNo === true) {
              setSelectedNo(true);
            } else {
              setSelectedNo(e.target.checked);
            }
          }}
          className="w-4 h-4 cursor-pointer"
        />

        <label className="ml-1 text-[15px]">No</label>
      </div>
    </div>
  );
}

export default YesNoCheckBoxes;
