"use client";
import GoogleLogo from "@/svgs/GoogleLogo";
import { Button } from "../ui/button";
import { Checkbox } from "../ui/checkbox";
import { Input } from "../ui/input";
import FacebookLogo from "@/svgs/FacebookLogo";
import XLogo from "@/svgs/XLogo";
import {
  Dispatch,
  SetStateAction,
  useContext,
  useEffect,
  useState,
} from "react";
import { Loader2 } from "lucide-react";
import {
  AuthModalSliderContext,
  ResetCurrentHighlightedAccountContext,
} from "./AuthenticationModal";
import { SubmitHandler, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { LoginInputTypes } from "../../../utilities/types";
import { loginSchema } from "../../../utilities/validationSchemas";
import axios from "axios";
import { domainName } from "../../../utilities/domainName";
import { TokenAccessContext } from "@/lib/userTokenContext";
import { LoginModalContext } from "@/lib/loginModalContext";
import Cookies from "universal-cookie";
import { useRouter } from "../../../node_modules/next/navigation";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { UserContext } from "@/lib/ContextApi/UserContext";

import { GoogleLogin } from "@react-oauth/google";

import {
  getProviders,
  ClientSafeProvider,
  LiteralUnion,
  signIn,
  // useSession,
  getSession,
  useSession,
} from "next-auth/react";
import { BuiltInProviderType } from "next-auth/providers";
import { Awaitable, getServerSession, NextAuthOptions, RequestInternal, User } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import GoogleProvider from "next-auth/providers/google";
import { useQuery } from "react-query";
import makeRequest from "../../../utilities/makeRequest";
import { authConfig } from "@/app/api/auth/[...nextauth]/route";

interface LoginProps {
  providers: Record<
    LiteralUnion<BuiltInProviderType, string>,
    ClientSafeProvider
  > | null;
}

// export const authConfig: NextAuthOptions = {
//   providers: [
//     GoogleProvider({
//       clientId: '341719446771-017uue501asl9a0p5u76bisdm95a0647.apps.googleusercontent.com',
//       clientSecret: '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',
//     }),
//   ],
//   pages: {
//     signIn: '/auth/signin',
//     error: '/auth/error/oommoo', // Error code passed in query string as ?error=
//   },
//   logger: {
//     error(code, ...message) {
//       console.error(code, ...message);
//     },
//     warn(code, ...message) {
//       console.warn(code, ...message);
//     },
//     debug(code, ...message) {
//       console.debug(code, ...message);
//     },
//   },
// }

// const [cookies, setCookie] = useCookies(['loggedInUserAccessToken']);



const Login: React.FC<LoginProps> = ({providers}) => {
  // const { data: session , status} = useSession();
  const cookies = new Cookies();
  // const postData = {
  //   email: session?.user?.email,
  //   username: "GsmSalihou",
  // };

  // const {
  //   isLoading,
  //   error: requestError,
  //   data,
  // } = useQuery(
  //   ["user"],
  //   () => axios.post('http://127.0.0.1:8000/getin/', postData).then((res) => res.data),
  //   {
  //     onSuccess: (data) => {
  //       console.log(data,"User from Header !!!!", data);
  //       // setUserData(data);
  //     },
  //   }
  // );

// useEffect(() => {

//   try{
//     data ? console.log('after sign in 1', data) : console.log('after sign in 1', 'Loading')
//   }catch (error) {
//     console.log('after sign in 2', 'Fail', error)
//   }

// }, [])

  

  function GoogleSignInButton() {
    const handleClick = () => {
      try{
        signIn("google");
      }catch(error){
        console.log('after sign in error ',error)
      }
    };
  
    return (
      <button
        onClick={handleClick}
        className="w-full flex items-center font-semibold justify-center h-14 px-6 mt-4 text-xl  transition-colors duration-300 bg-white border-2 border-black text-black rounded-lg focus:shadow-outline hover:bg-slate-200"
      >
        <span className="ml-4">Continue with Google</span>
      </button>
    );
  }



// ....................................
// ....................................

const { data: session, status } = useSession();

// if (status === 'loading') {
//   return <p>Loading...</p>;
// }

// if(status === 'authenticated') {
  
//   cookies.set("loggedInUserAccessToken", session?.accessKey, {
//     expires: new Date(Date.now() + 3600 * 1000 * 24),
//   })
//   cookies.set("userPK", session?.user_pk, {
//     expires: new Date(Date.now() + 3600 * 1000 * 24),
//   })

// }

// console.log("From Route :::",session?.accessKey)




// ......................................
// ....................................
  


  //..use for redirect
  const router = useRouter();
  // console.log(pathname)

  // const { data: session } = useSession();
  //.............................
  
  const [errorMsg, setErrorMsg] = useState("");
  const { userData, setUserData } = useContext(UserContext);
  const setAuthModalSlider = useContext(AuthModalSliderContext);
  const { userAccess, setUserAccess } = useContext(TokenAccessContext);
  const { modalState, setModalState } = useContext(LoginModalContext); //modal context
  const ResetCurrentHighlightedAccount = useContext(
    ResetCurrentHighlightedAccountContext
  );


  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors },
  } = useForm<LoginInputTypes>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit: SubmitHandler<LoginInputTypes> = (data: any) => {
    setIsLoggingIn(true);
    axios
      .post(`${domainName}/login/`, data)
      .then((response: any) => {
        setUserData(response.data.user);
        //...............End Here ........................................................................
        cookies.set("loggedInUserAccessToken", response.data.access, {
          expires: new Date(Date.now() + 3600 * 1000 * 24),
        });
        cookies.set("userPK", response.data.user.pk, {
          expires: new Date(Date.now() + 3600 * 1000 * 24),
        });
        console.log(response.data.user, "from login");
        // update userTokenContext
        setUserAccess({ access: true });
        //close the login modal
        setModalState({ isOpen: false });
        setIsLoggingIn(false);
        return window.location.reload();
      })
      .catch((error: any) => {
        setErrorMsg(error?.response?.data?.non_field_errors[0]);
        if (error?.response?.data?.non_field_errors[0]) {
          setIsLoggingIn(false);
        }
      });
  };

  // .........................
  // ......................
  // const handleLoginSuccess = (credentialResponse: any) => {
  //   console.log('Login Success:', credentialResponse);
  //   // You can send the credential to your backend for verification and further processing
  //   // setUser with the response data if needed
  // };

  // const handleLoginFailure = (error: void) => {
  //   console.error('Login Failed:', error);
  // };



  

 

  //  useEffect( () => {
    // const registerUser = async () => {
    //   //   try {
    //   console.log("from top register fn ");

    //    if (session?.user?.email) {

    //     const response = await axios.post("http://127.0.0.1:8000/getin/",postData) 

    //     console.log(response?.data)
    //   }

     

    // }
    //  registerUser()
    //     const { email, username, accessToken } = response.data; // Assuming accessToken is returned from Django
  
    //     setRegisteredUser({ email, username });
    //     // Save accessToken in cookies
    //     cookies.set("accessToken", accessToken);
  
    //     response.data ? setRegisterData(true) : setRegisterData(false);
  
    //     console.log("User registered and data sent to /getin/ : ", response.data);
    //   } catch (error) {
    //     console.error("Error registering user or sending data:", error);
    //   }
    // };

    // // if (session?.user) {
    //   console.log("from top effect ");
    //   // if (registerData) {
    //     registerUser();
    //   // }

    // // }
    // console.log("from bottom effect ");

    //const post_data = {'email': user.email, 'username': user.username}
    //const res = await axios.post('http://127.0.0.1:8000/getin/', { email, username });


    // cookies.set('loggedInUserAccessToken', session?.accessToken, {
    //   expires: new Date(Date.now() + 3600 * 1000 * 24),
    // });



  // }, [postData])

 

  // const post_data = {'email': user.email, 'username': user.username}
  // const res = await axios.post('http://127.0.0.1:8000/getin/', { email, username });
  // cookies.set('loggedInUserAccessToken', session?.accessToken, {
  //   expires: new Date(Date.now() + 3600 * 1000 * 24),
  // });

  // ..................
  // .........................

  return (
    <div className="hide-scroll-bar max-sm:h-[86vh] max-md:pb-5 max-md:pt-10 max-[280px]:py-1 max-h-[86vh] overflow-y-scroll w-full max-[280px]:h-[20rem] max-[280px]:overflow-y-scroll pl-8 max-sm:pr-9 max-md:pr-0 max-md:pl-8 max-sm:pl-4">
      <div className="max-sm:mt-6">
        <p className="max-[280px]:text-[23px] text-[40px] max-sm:text-[25px] max-md:text-[32px] font-thin italic text-gray-800">
          Welcome Back
        </p>
        <form onSubmit={handleSubmit(onSubmit)} noValidate>
          <div className="mt-3 mb-3 w-full">
            <label className="text-[14px]">Email Address</label>
            <Input
              placeholder="Email Address"
              className=" rounded-full mt-1 text-[12px] border-black border-[0.5px]"
              type="email"
              {...register("email")}
            />
            {errors.email && <p className="errors">{errors.email?.message}</p>}
          </div>
          <div>
            <label className="text-[14px]">Password</label>
            <Input
              placeholder="Password"
              className="mb- rounded-full text-[12px] border-black border-[0.5px] "
              type="password"
              {...register("password")}
            />
            {errors.password && (
              <p className="errors mb-3">{errors.password?.message}</p>
            )}
            {errorMsg && (
              <>
                <p className="errors">
                  The email or password you entered is incorrect. Please check
                  your credentials and try again.
                </p>
              </>
            )}
          </div>
          {/* <Link href='/' className='text-xs font-bold ml-2 text-indigo-800' >Forgot password?</Link> */}

          <div className="flex items-center justify-between mt-4 max-[370px]:flex-col">
            <div className="flex items-center max-[370px]:self-start">
              <Checkbox id="keep-me-logged-in" className="w-5 h-5" />
              <label
                htmlFor="keep-me-logged-in"
                className="text-[11px] ml-[8px] font-[550] leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Keep me logged in
              </label>
            </div>
            <Button
              variant={"lightBlue"}
              className="text-[12px] px-6 max-sm:px-4 max-sm:py-[6px] max-[370px]:w-full max-[370px]:mt-6"
              size={"lightBlue"}
              type="submit"
            >
              {isLoggingIn ? (
                <>
                  <Loader2 className="h-[18px] w-[18px] animate-spin" />
                </>
              ) : (
                <p>Log in</p>
              )}
            </Button>
          </div>
        </form>
      </div>
      {/* mb-4 to be changed to -mb-4 */}
      <div className="flex items-center justify-center mt-6 mb-4">
        <p className="text-[14px] max-sm:text-xs text-gray-600 text-nowrap">
          Not a member yet?
        </p>
        <button
          className="font-bold ml-1 text-[15px] max-sm:text-[14px] text-nowrap"
          onClick={() => {
            setAuthModalSlider?.setAuthModalSlider("-translate-x-[37.5%]");
            ResetCurrentHighlightedAccount?.setResetCurrentHighlightedAccount(
              false
            );
            if (errors.email?.message) {
              errors.email.message = "";
            }
            if (errors.password?.message) {
              errors.password.message = "";
            }
            if (getValues().email) {
              setValue("email", "");
            }
            if (getValues().password) {
              setValue("password", "");
            }
          }}
        >
          Sign Up
        </button>
      </div>

      <div className="mt-10 max-sm:mb-8">
        {/* <Button
          onClick={() => {
            // router.push("https://server.oommoo.xyz/login/google-oauth2/");
            // window.open("https://server.oommoo.xyz/login/google-oauth2/");
            // window.open(" http://127.0.0.1:8000/google-signup");
            //       const initiateGoogleLogin = () => {
            //       const clientId = '341719446771-017uue501asl9a0p5u76bisdm95a0647.apps.googleusercontent.com';
            //       const redirectUri = 'http://127.0.0.1:3000';
            //       const scope = 'https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email';
            //       const state = 'some_random_state';  // Use a real random state for CSRF protection
            //       const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code&scope=${scope}&state=${state}`;
            //       window.location.href = authUrl;



            //     axios
            //     .post('https://accounts.google.com/o/oauth2/v2/auth',{ clientId, redirectUri, scope, state}
                  
            //     )
            //     .then((response: any) => {
            //       console.log(response)

            //     })
            //     .catch((error: any) => {
            //  console.log(error)
            //     })
            //   }
            //   initiateGoogleLogin()
          }}
          className="w-full border border-gray-200 py-[0.4rem]  rounded-full mb-2 max-sm:mb-3 max-md:active:bg-gray-200 md:hover:bg-gray-200 justify-center"
        > */}
        {/* <div className="flex items-center -ml-3">
            <GoogleLogo />
            <p className="text-[12.5px] max-[280px]:ml-1 text-black font-medium ml-4">
              Log in with Google
            </p>
          </div>
        </Button> */}

        <GoogleSignInButton />

        {/* <GoogleLogin onSuccess={handleLoginSuccess} onError={handleLoginFailure} /> */}
        {/* <SocialAuth  /> */}
        
        {/* <button onClick={() => signIn()}>Sign in Google</button> */}

        {/* <Button
          onClick={() => {
            // router.push("https://server.oommoo.xyz/login/facebook");
            window.open("https://server.oommoo.xyz/login/facebook");
          }}
          className="w-full rounded-full mb-2 py-[0.3rem] max-sm:mb-3 bg-blue-500 max-md:active:bg-blue-600 md:hover:bg-blue-600 justify-center"
        >
          <div className="flex items-center">
            <FacebookLogo width="w-7 max-sm:w-6" />
            <p className="text-white text-[12.5px] font-medium ml-3">
              Log in with Facebook
            </p>
          </div>
        </Button>
        <Button className="w-full rounded-full bg-black max-md:active:bg-neutral-800 md:hover:bg-neutral-800 text-white justify-center">
          <div className="flex items-center -ml-11">
            <XLogo width="w-5 max-sm:w-4" />
            <p className="text-[12.5px] font-medium ml-5">Log in with X</p>
          </div>
        </Button> */}
      </div>
    </div>
  );
};

export default Login;


// export async function getServerSideProps({ req, res }) {
//   return {
//     props: {
//       session: await getSession( )
//     }
//   }
// }

// export async function getServerSideProps() {
//   const providers = await getProviders();
//   return {
//     props: { providers },
//   };
// }
