"use client";
import Star from "@/svgs/Star";
import { useState } from "react";
import { Textarea } from "../ui/textarea";
import { Button } from "../ui/button";

function ReviewForm() {
  const [currentReviewCharacters, setCurrentReviewCharacters] = useState("");
  const [highlightedStars, setHighlightedStars] = useState(0);
  const [selectedStars, setSelectedStars] = useState(0);

  return (
    <form>
      <div className="flex items-center mt-3">
        {[...Array(5)].map((_, index) => {
          return (
            <button
              key={index}
              onClick={() => {
                if (selectedStars === index + 1) {
                  setSelectedStars(0);
                } else {
                  setSelectedStars(index + 1);
                }
              }}
              onMouseOver={() => {
                setHighlightedStars(index + 1);
              }}
              onMouseLeave={() => {
                setHighlightedStars(0);
              }}
              type="button"
            >
              <Star
                width="w-5"
                height="h-5"
                color={`${
                  index + 1 <= selectedStars
                    ? "fill-yellow-400"
                    : "fill-gray-300"
                }  ${
                  index + 1 <= highlightedStars
                    ? "fill-yellow-400"
                    : "fill-gray-300"
                }`}
                marginLeft="ml-1"
              />
            </button>
          );
        })}

        <p className="text-white font-bold text-lg ml-3">{selectedStars}/5</p>
      </div>
      <div className="flex flex-col mt-6">
        <Textarea
          className="resize-none bg-[#D9D9D9] textarea h-[17vh] p-4 text-gray-800"
          placeholder="Add a comment"
          maxLength={500}
          onChange={(event) => {
            setCurrentReviewCharacters(event.target.value);
          }}
          value={currentReviewCharacters}
        />
        <Button
          disabled={selectedStars && currentReviewCharacters ? false : true}
          className="bg-[#F6C20A] hover:bg-yellow-600 text-black font-bold px-3 py-2 text-base self-end mt-4"
        >
          Submit
        </Button>
      </div>
    </form>
  );
}

export default ReviewForm;
