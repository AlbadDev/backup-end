"use client"
import React, { useState } from 'react'

import { 
	TabContent, TabPane, Nav, 
	NavItem, NavLink, Row, Col 
} from 'reactstrap'; 
import classnames from 'classnames'; 

function TableContent() { 

	// State for current active Tab 
	const [currentActiveTab, setCurrentActiveTab] = useState('1'); 

	// Toggle active state for Tab 
	const toggle = tab => { 
		if (currentActiveTab !== tab) setCurrentActiveTab(tab); 
	} 

	return ( 
		<div style={{ 
			display: 'block', width: 700, padding: 30 
		}}> 
			<h4>ReactJS Reactstrap Tab Component</h4> 
			<Nav tabs> 
				<NavItem> 
					<NavLink 
						className={classnames({ 
							active: 
								currentActiveTab === '1'
						})} 
						onClick={() => { toggle('1'); }} 
					> 
						Tab1 
					</NavLink> 
				</NavItem> 
				<NavItem> 
					<NavLink 
						className={classnames({ 
							active: 
								currentActiveTab === '2'
						})} 
						onClick={() => { toggle('2'); }} 
					> 
						Tab2 
					</NavLink> 
				</NavItem> 
				<NavItem> 
					<NavLink 
						className={classnames({ 
							active: 
								currentActiveTab === '3'
						})} 
						onClick={() => { toggle('3'); }} 
					> 
						Tab3 
					</NavLink> 
				</NavItem> 
			</Nav> 
			<TabContent activeTab={currentActiveTab}> 
				<TabPane tabId="1"> 
					<Row> 
						<Col sm="12"> 
							<h5>Sample Tab 1 Content</h5> 
						</Col> 
					</Row> 
				</TabPane> 
				<TabPane tabId="2"> 
					<Row> 
						<Col sm="12"> 
							<h5>Sample Tab 2 Content</h5> 
						</Col> 
					</Row> 
				</TabPane> 
				<TabPane tabId="3"> 
					<Row> 
						<Col sm="12"> 
							<h5>Sample Tab 3 Content</h5> 
						</Col> 
					</Row> 
				</TabPane> 
			</TabContent> 
		</div > 
	); 
} 

export default TableContent;










// 'use client'
// import style from '../../../styles/TableContent.module.scss'
// import Link from 'next/link'
// import { useContext, useState } from 'react'
// import { Button, Card, CardText, CardTitle, Col, Nav, NavItem, NavLink, Row, TabContent, TabPane } from 'reactstrap'




// export const TableContent = () => {

//     constructor(props) {
//         super(props);
    
//         this.toggle = this.toggle.bind(this);
//         this.state = {
//           activeTab: '1'
//         };
//       }
    
//       toggle(tab) {
//         if (this.state.activeTab !== tab) {
//           this.setState({
//             activeTab: tab
//           });
//         }
//       }

   
//     // const [activeTab, setActiveTab] = useState('2');

//     // const toggle = (tab) => {
//     //     if (activeTab !== tab) {
//     //         setActiveTab(tab);
//     //         console.log(tab)
//     //     }
//     // };

//     return (
//         <div>
//         <Nav tabs>
//           <NavItem>
//             <NavLink
//               className={classnames({ active: this.state.activeTab === '1' })}
//               onClick={() => { this.toggle('1'); }}
//             >
//               Tab1
//             </NavLink>
//           </NavItem>
//           <NavItem>
//             <NavLink
//               className={classnames({ active: this.state.activeTab === '2' })}
//               onClick={() => { this.toggle('2'); }}
//             >
//               Moar Tabs
//             </NavLink>
//           </NavItem>
//         </Nav>
//         <TabContent activeTab={this.state.activeTab}>
//           <TabPane tabId="1">
//             <Row>
//               <Col sm="12">
//                 <h4>Tab 1 Contents</h4>
//               </Col>
//             </Row>
//           </TabPane>
//           <TabPane tabId="2">
//             <Row>
//               <Col sm="6">
//                 <Card body>
//                   <CardTitle>Special Title Treatment</CardTitle>
//                   <CardText>With supporting text below as a natural lead-in to additional content.</CardText>
//                   <Button>Go somewhere</Button>
//                 </Card>
//               </Col>
//               <Col sm="6">
//                 <Card body>
//                   <CardTitle>Special Title Treatment</CardTitle>
//                   <CardText>With supporting text below as a natural lead-in to additional content.</CardText>
//                   <Button>Go somewhere</Button>
//                 </Card>
//               </Col>
//             </Row>
//           </TabPane>
//         </TabContent>
//       </div>
//         // <div className={style.tableContainer}>

//         //     <Tab.Container id="left-tabs-example" defaultActiveKey="second" className={style.container}>

//         //     <div className={style.cardContainer} >
//         //         <div className={style.navContainer}>


//         //             <Nav tabs className={style.infoLink}>
//         //                 <NavItem className={style.infoLink} style={{cursor:"pointer"}}>
//         //                     <NavLink
//         //                         className={activeTab === '1' ? 'active' : 'notActive'}
//         //                         onClick={() => toggle('1')}
//         //                        id={style.navlINK}
//         //                     >
//         //                       Profile

//         //                     </NavLink>
//         //                 </NavItem>
//         //                 <NavItem  style={{cursor:"pointer"}}>
//         //                     <NavLink
//         //                         className={activeTab === '2' ? 'active' : 'notActive'}
//         //                         onClick={() => toggle('2')}
//         //                     >
//         //                         Timeline
//         //                     </NavLink>
//         //                 </NavItem>
//         //                 <NavItem  style={{cursor:"pointer"}}>
//         //                     <NavLink
//         //                         className={activeTab === '3' ? 'active' : 'notActive'}
//         //                         onClick={() => toggle('3')}
//         //                     >
//         //                         Gallery
//         //                     </NavLink>
//         //                 </NavItem>
//         //             </Nav>


//         //             <TabContent activeTab={activeTab} >
//         //                 <TabPane tabId="1" >
//         //                     <Row >
//         //                         <Col sm="12" >
//         //                             <div className={style.profileBodyContainer} >

//         //                                hello 1
                                        
//         //                             </div>
//         //                         </Col>
//         //                     </Row>
//         //                 </TabPane>
//         //                 <TabPane tabId="2">
//         //                     <Row>
//         //                         Hello 2
//         //                     </Row>
//         //                 </TabPane>
//         //                 <TabPane tabId="3" >
//         //                     <Row >
//         //                         <Col sm="12" >
//         //                             <div style={{paddingTop:50,textAlign:'center'}}>
//         //                                hello 3
//         //                             </div>
//         //                         </Col>
//         //                     </Row>
//         //                 </TabPane>
//         //             </TabContent>

//         //         </div>

//         //     </div>
//         //     </Tab.Container>
//         // </div>
//     )
// }

// export default TableContent