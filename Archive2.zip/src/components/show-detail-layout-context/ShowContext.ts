"use client"
import { Dispatch, SetStateAction, createContext, useState } from "react";

export const ShowReviewModalContext = createContext<null | {
  showReviewModal: boolean;
  setShowReviewModal: Dispatch<SetStateAction<boolean>>;
}>(null);
export const ShowCastsContext = createContext<null | {
  showCasts: boolean;
  setShowCasts: Dispatch<SetStateAction<boolean>>;
}>(null);
export const ShowAudienceOrIndustryReviewsContext = createContext<null | {showAudienceOrIndustryReviews: string, setShowAudienceOrIndustryReviews: Dispatch<SetStateAction<string>>}>(null)
export const CurrentAuthUserIsSubmittedReviewContext = createContext<null | {currentAuthUserIsSubmittedReview: boolean, setCurrentAuthUserIsSubmittedReview: Dispatch<SetStateAction<boolean>>}>(null)
