"use client";
import Search from "@/svgs/Search";
import UserProfilePictureAvatar from "./UserProfilePictureAvatar";
import Link from "next/link";
import { useQuery } from "react-query";
import LoginButton from "./LoginButton";
import OommooLogo from "@/svgs/OommooLogo";
import WatchlistLogo from "@/svgs/WatchlistLogo";
import { ShowAuthenticationModalContext } from "./HeaderAndAuthModal";
import MenuBar from "@/svgs/MenuBar";
import { TokenAccessContext } from "@/lib/userTokenContext";
import { useContext, useEffect, useState } from "react";
import Cookies from "universal-cookie";
import AccountMenu from "../../../utilities/MenuButton";
import makeRequest from "../../../utilities/makeRequest";
import { UserContext } from "@/lib/ContextApi/UserContext";
import { getServerSession } from "next-auth";
import { authConfig } from "@/app/api/auth/[...nextauth]/route";


// const sessionData = getServerSession(authConfig)

// console.log(sessionData,'From Header')

export const  Header = () => {

  


  const cookies = new Cookies();
  const { userData, setUserData } = useContext(UserContext);
  const { userAccessToken, setUserAccessToken } =
    useContext(TokenAccessContext);
  let resCookie = cookies.get("userPK");
  // const { currentUser, setCurrentUser } = useState(null)

  const {
    isLoading,
    error: requestError,
    data,
  } = useQuery(
    ["user"],
    () => makeRequest.get(`/user/${resCookie}`).then((res) => res.data),
    {
      onSuccess: (data) => {
        // console.log(data,"User from Header !!!!",resCookie);
        setUserData(data);
      },
    }
  );






  return (
    <div>
      <header className="bg-black pt-[2.2rem] pb-[1.2rem] fixed right-0 left-0 z-20">
        <div className="flex items-center justify-around w-[100%] mx-auto mb-2">
          {/* <button>
            <MenuBar />
          </button> */}
          <Link
            href={"/"}
            className="flex items-center flex-col max-[230px]:hidden"
          >
            <OommooLogo />
            
            <p className="font-medium text-white max-lg:text-[0.6rem] text-xs italic w-full text-center">
              One of many. many of One  
            </p>
          </Link>
          <div className="max-md:hidden flex items-center bg-white w-[45%] rounded-full -mt-4 pl-4 max-[900px]:w-[43%]">
            <Search className="w-[22px] h-[22px] text-gray-700" />
            <input
              placeholder="Search"
              className="p-[6px] rounded-full outline-none ml-3 w-[70%] "
            />
          </div>
          {/* <button className="md:hidden">
            <Search className="text-white w-[20px] h-[30px]" />
          </button> */}
          <Link href="/" className="flex items-center -mt-4 max-md:hidden">
            <WatchlistLogo />
            <p className="font-bold text-white text-[1.1rem] ml-[0.4vw]">
              Watchlist
            </p>
          </Link>
          {userData.pk ? (
            // <UserProfilePictureAvatar />
            <AccountMenu />
          ) : (
            <LoginButton />
          )}
        </div>
        <div className="md:hidden flex items-center bg-white w-[95%] rounded-full mt-15 ml-5 pl-4 max-[900px]:w-[90%]">
          <Search className="w-[22px] h-[22px] text-gray-700" />
          <input
            placeholder="Search"
            className="p-[6px] rounded-full outline-none ml-3 w-[70%] "
          />
        </div>
      </header>
    </div>
  );
}

export default Header;
