

import FacebookLogo from "@/svgs/FacebookLogo";
import GoogleLogo from "@/svgs/GoogleLogo";
import InstagramLogo from "@/svgs/InstagramLogo";
import OommooLogo from "@/svgs/OommooLogo";
import TikTokLogo from "@/svgs/TikTokLogo";
import XLogo from "@/svgs/XLogo";
import YoutubeLogo from "@/svgs/YoutubeLogo";
import Link from "next/link";



 function Footer() {

 

  return (
    <footer className="bg-black p-8">
      <div className="w-[40%] flex text-left max-[360px]:w-full">
        {/* <Link href={"/"} className="flex items-center flex-col">
          <OommooLogo className="max-[230px]:w-[110px]" />
          <p className="font-medium text-white max-lg:text-[0.6rem] text-xs italic w-full text-center">
            One of many. many of One
          </p>
        </Link> */}
      </div>
      <div className="flex items-center flex-col max-lg:w-[70%] max-sm:w-full max-lg:mt-8 bg-[#D9D9D91A] w-[47%] mx-auto px-4 pt-2 pb-5 rounded-[30px] border-[0.1px] border-neutral-800">
        <p className="flex items-center flex-col text-white max-[270px]:grid max-[270px]:grid-cols-3 max-[270px]:gap-8 max-[270px]:grid-rows-2 flex justify-between items-center w-[63%] max-sm:w-full mt-4 max-">info@oommoo.xyz</p>
        {/* <p
          className="text-white text-[21px] font-bold max-md:text-[20px] 
    max-[360px]:text-[14px]
        max-lg:text-[22px]        
        "
        >
          Follow us on Social Media
        </p>
        <div className="max-[270px]:grid max-[270px]:grid-cols-3 max-[270px]:gap-8 max-[270px]:grid-rows-2 flex justify-between items-center w-[63%] max-sm:w-full mt-4 max-">
          <FacebookLogo width="w-[2.7rem] max-[360px]:w-[1.8rem] max-md:w-[2.5rem]" />
          <XLogo width="w-[2rem] max-[360px]:w-[1.4rem] max-md:w-[1.8rem]" />
          <InstagramLogo />
          <TikTokLogo />
          <YoutubeLogo />
        </div> */}
      </div>
      {/* <div className="flex max-lg:my-16 items-center justify-between mt-8 max-lg:grid max-lg:-grid-rows-2 max-lg:grid-cols-3 max-sm:grid-rows-3 max-sm:grid-cols-2 max-[334px]:grid-cols-1 max-lg:gap-10 max-[385px]:grid-cols-2">
        <p className="max-[360px]:text-[15px] max-md:font-semibold max-[360px]:font-medium text-white text-[18px] max-[385px]:text-[15px] max-[334px]:text-center font-semibold">
          Your activity
        </p>
        <p className="max-[360px]:text-[15px] max-md:font-semibold max-[360px]:font-medium text-white text-[18px] max-[385px]:text-[15px] max-[334px]:text-center font-semibold">
          Your watchlist
        </p>
        <p className="max-[360px]:text-[15px] max-md:font-semibold max-[360px]:font-medium text-white text-[18px] max-[385px]:text-[15px] max-[334px]:text-center font-semibold">
          Your ratings
        </p>
        <p className="max-[360px]:text-[15px] max-md:font-semibold max-[360px]:font-medium text-white text-[18px] max-[385px]:text-[15px] max-[334px]:text-center font-semibold">
          FAQs
        </p>
        <p className="max-[360px]:text-[15px] max-md:font-semibold max-[360px]:font-medium text-white text-[16px] max-[385px]:text-[15px] max-[334px]:text-center font-semibold">
          Conditions of use
        </p>
        <p className="max-[360px]:text-[15px] max-md:font-semibold max-[360px]:font-medium text-white text-[18px] max-[385px]:text-[15px] max-[334px]:text-center font-semibold">
          Privacy policy
        </p>
      </div> */}
      <div className="mt-8">
        <p className="max-[280px]:text-[13px] text-white text-center text-lg max-[400px]:text-[17px] max-[343px]:text-[13px]">
          <span>&#169;</span> 2024 OommoO Beta version, All rights reserved
        </p>
      </div>
    </footer>
  );
}

export default Footer;
