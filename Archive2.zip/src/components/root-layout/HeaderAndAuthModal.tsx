"use client";
import AuthenticationModal from "../authentication/AuthenticationModal";
import Header from "./Header";
import { Dispatch, SetStateAction, createContext, useState, useContext } from "react";
import { LoginModalContext } from "@/lib/loginModalContext";

export const ShowAuthenticationModalContext = createContext<{
  showAuthenticationModal: boolean
  setShowAuthenticationModal: Dispatch<SetStateAction<boolean>>;
} | null>(null);




function HeaderAndAuthModal({children}:any) {
  // const [showAuthenticationModal, setShowAuthenticationModal] = useState(false);

  const  { modalState, setModalState } = useContext(LoginModalContext); //modal context




  return (
    <>
      {/* <ShowAuthenticationModalContext.Provider
        value={{ showAuthenticationModal  ,setShowAuthenticationModal }}
      > */}
        <Header />
        {modalState.isOpen ? 
          <div>
            <AuthenticationModal />

            <div
              className="bg-black fixed top-0 left-0 right-0 bottom-0 opacity-60 z-20"
              onClick={() => {
                setModalState({isOpen:false})
              }}
            ></div>
          </div>
         : null
        
        }
      {/* </ShowAuthenticationModalContext.Provider> */}
    {children}
    </>

  );
}

export default HeaderAndAuthModal;
