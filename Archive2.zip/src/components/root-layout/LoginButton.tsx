"use client";

import { Button } from "@/components/ui/button";
import { useContext } from "react";
// import { ShowAuthenticationModalContext } from "./HeaderAndAuthModal";
import { LoginModalContext } from "../../lib/loginModalContext";
import LoginRoundedIcon from '@mui/icons-material/LoginRounded';












function LoginButton() {
  const { modalState, setModalState } = useContext(LoginModalContext);
  // const { userAccess, setUserAccess } = useContext(TokenAccessContext);

  return (
    <Button
      variant="secondary"
      className="
      max-[360px]:px-[0.6rem]
      max-[300px]:hidden
      max-md:mt-0 bg-white px-[1rem] h-0 py-[1rem] text-[1rem] font-bold -mt-4 rounded-full"
      onClick={() => {
        setModalState({ isOpen: true });
      }}
    >
      <LoginRoundedIcon style={{padding:'0px 3px'}}/>
      Login
    </Button>
  );
}

export default LoginButton;
