"use client";  
import Plus from "@/svgs/Plus";
import Star from "@/svgs/Star";
import Image from "next/image";
import React, { useState } from "react";
import { Button } from "../ui/button";
import Link from "next/link";
import { truncateText } from "../../../utilities/truncateText";

function Show(props: {
  id: number;
  title: string;
  summary: string;
  image: string;
  // numberOfReviews: string;
  // typeOfEvent: [string, string, string];
  averageRatings: number;
  slug: string;
  ratingsCount: number;
}) {
  const [showTitleAndSummary, setShowTitleAndSummary] = useState(false);
  return (
    <div
      className="relative
      overflow-hidden
      max-md:mb-[3.2%]
    mb-[27px] mx-[1.5vw] bg-black pb-2 rounded-lg cursor-pointer
    transition-all md:hover:scale-110
    w-[21.6%]
    max-lg:w-[30%]
    max-lg:ml-[1.6%]
    max-sm:w-[46%]
    max-md:w-[29%]
    max-sm:mx-[2%]
    max-md:mx-[2.1%]
    max-[360px]:w-[95%]
    max-[360px]:mx-auto
    "
      onMouseOver={() => {
        setShowTitleAndSummary(true);
      }}
      onMouseLeave={() => {
        setShowTitleAndSummary(false);
      }}
    >
      <Link href={`shows/${props.slug}`}>
        <Image
          src={props.image}
          alt={props.title}
          width={255.7}
          height={100}
          className="
              max-[360px]:h-[12rem]
          max-md:h-[15rem] h-[20rem] w-full rounded-t-lg object-cover"
        />

        <div className="flex items-center mt-1 ml-[0.5vw]">
          <div className="flex items-center">
            {[...Array(5)].map((_, index) => {
              return (
                <Star
                  key={index}
                  width="w-[0.8rem]"
                  color={`${
                    index + 1 <= props.averageRatings
                      ? "fill-yellow-400"
                      : "fill-gray-300"
                  }`}
                  marginLeft="default"
                />
              );
            })}
          </div>
          <p className="font-extrabold text-white text-[0.8rem] ml-2 mt-[2px]">
            {props.ratingsCount}
          </p>
        </div>
        <div className="flex items-center justify-around mt-1">
          <p className="font-extrabold text-white text-[0.8rem] lg:text-[0.7rem] md:text-[0.7rem] max-md:text-[0.6rem] max-sm:text-[0.5rem]">
            AfroFuturism
          </p>
          <p className="font-extrabold text-white text-[0.8rem] lg:text-[0.7rem] md:text-[0.7rem] max-md:text-[0.6rem] max-sm:text-[0.5rem]">Drama</p>
          <p className="font-extrabold text-white text-[0.8rem] lg:text-[0.7rem] md:text-[0.7rem] max-md:text-[0.6rem] max-sm:text-[0.5rem]">Music</p>
        </div>
      </Link>
      <Button
        variant={"ghost"}
        className="absolute top-1 rounded-full right-2 px-[0.37vw] py-[0.8vh] z-10"
        onClick={() => {
        }}
        title="add to watchlist"
      >
        <Plus />
      </Button>
      <div className="max-md:hidden absolute top-0 left-0 right-0 bottom-0 bg-black opacity-20 rounded-lg transition-all"></div>
      {showTitleAndSummary && (
        <Link href={`shows/${props.slug}`}>
          <div className="max-md:hidden absolute top-0 left-0 right-0 bottom-0 bg-gradient-to-t from-black to-transparent opacity-70 rounded-lg transition-all"></div>
          <div className="max-w absolute bottom-[18%]">
            <div className="relative px-2">
              <p
                className="max-md:hidden text-gray-200 capitalize font-bold relative z-10 text-[1rem]"
                title={`${props.title}`}
              >
                {truncateText(props.title, 25)}
              </p>
              <p className="max-md:hidden text-gray-200 relative z-10 text-[0.7rem] font-normal">
                {truncateText(props.summary, 120)}
              </p>
            </div>
          </div>
        </Link>
      )}
    </div>
  );
}

export default Show;
