// "use client";

import React, { useContext, useEffect, useState } from "react";
import Show from "@/components/home-page/Show";
import { domainName } from "../../../utilities/domainName";
import { TokenAccessContext } from "../../lib/userTokenContext";

interface ShowType {
    id: number,
    title: string,
    summary: string, 
    image: string,
    slug: string,
    ratings_count: number,
    average_rating: number,
    key: number,
}
async function fetchShows() {
  const response = await fetch(`${domainName}/shows/`, {
    cache: "no-store",
  });
  if (!response.ok) {
    throw new Error("failed to fetch shows");
  }
  return response.json();
}

const ShowDisplay = () => {
  const { userAccess, setUserAccess } = useContext(TokenAccessContext);
  const [shows, setShows] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const getShows = async () => {
      try {
        const data = await fetchShows();
        setShows(data.results);
      } catch (err:any) {
        setError(err.message);
      }
    };
    getShows();
  }, []);


  const handleAccessChange = () => {
    setUserAccess({ access: !userAccess.access });
  };

  if (error) {
    return <div>Error: {error}</div>;
  }
  return (
    <main className="bg-[#1A1A1A] max-md:bg-black">
      <button onClick={handleAccessChange}>Toggle Access</button>
      <div className="max-md:pt-[7rem] flex flex-wrap pt-[8rem] items-center w-[92vw] mx-auto">
        {shows.map((show: ShowType, index ) => (
          <Show
            id={show.id}
            title={show.title}
            summary={show.summary}
            image={show.image}
            slug={show.slug}
            averageRatings={show.average_rating}
            ratingsCount={show.ratings_count}
            key={show.id}
          />
        ))}
      </div>
    </main>
  );
};

export default ShowDisplay;
