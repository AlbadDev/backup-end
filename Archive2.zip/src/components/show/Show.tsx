"use client";
import AudienceIndustryReviews from "@/components/show/AudienceIndustryReviews";
import ShowDetail from "@/components/show/ShowDetail";
import { Dispatch, SetStateAction, createContext, useState } from "react";

export const TriggerDataFetchingContext = createContext<{
  triggerDataFetching: number;
  setTriggerDataFetching: Dispatch<SetStateAction<number>>;
}>({
  triggerDataFetching: 0,
  setTriggerDataFetching: () => {}
});

function Show({ params }: { params: { showName: string } }) {
  const [triggerDataFetching, setTriggerDataFetching] = useState(0);

// function Show({ params }: { params: { showName: string, showSlug:string } }) {

  return (
    <main className="bg-white">
      <TriggerDataFetchingContext.Provider
        value={{ triggerDataFetching, setTriggerDataFetching }}
      >
        <ShowDetail params={params} setReviewModalIsClosed={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        } } />
        <div>
          <AudienceIndustryReviews params={params} />
        </div>
      </TriggerDataFetchingContext.Provider>
    </main>
  );
}

export default Show;
