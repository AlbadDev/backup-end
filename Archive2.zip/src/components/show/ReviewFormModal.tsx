"use client";
import Star from "@/svgs/Star";
import { Button } from "../ui/button";
import { Dispatch, SetStateAction, useContext, useEffect, useRef, useState } from "react";
import { useBodyScrollLock } from "../../../utilities/lockscroll";
import { Textarea } from "@/components/ui/textarea";
import "@/components/show/show-styles.css";
import { ShowReviewModalContext } from "../show-detail-layout-context/ShowContext";
import axios from "axios";
import { domainName } from "../../../utilities/domainName";
import Cookies from "universal-cookie";
import { TokenAccessContext } from "@/lib/userTokenContext";
import TriggerDataFetchingContext from "../../../utilities/TriggerDataFetchingContext";
import { LoginModalContext } from "@/lib/loginModalContext";

function ReviewFormModal({
  showID,
  showName,
  setCurrentUserIsSubmittedReview,
  setReviewModalIsClosed,
}: {
  showID: number;
  showName: string;
  setCurrentUserIsSubmittedReview: Dispatch<SetStateAction<boolean>>;
  setReviewModalIsClosed: Dispatch<SetStateAction<boolean>>
}) {
  const cookies = new Cookies();
  useBodyScrollLock();
  const showReviewModal = useContext(ShowReviewModalContext);
  const [highlightedStars, setHighlightedStars] = useState(0);
  const { modalState, setModalState } = useContext(LoginModalContext);
  const [selectedStars, setSelectedStars] = useState(0);
  const [currentReviewCharacters, setCurrentReviewCharacters] = useState("");
  const triggerDataFetching = useContext(TriggerDataFetchingContext);


  return (
    <>
      <div className="fixed max-sm:w-[80vw] max-sm:left-[10vw] top-[20vh] bg-white w-[50vw] rounded-2xl left-[25vw] pt-3 z-30">
        <p className="text-center font-medium text-2xl capitalize">
          {showName.replaceAll('-', ' ') }       
          </p>
        <p className="text-center font-medium text-[1rem]">
          Lula Mehbrahtu 2024
        </p>
        <div className="flex items-center justify-between max-sm:w-[73%] max-[390px]:w-[80%] max-sm:pl-4 lg:w-[61%] w-[68%] mt-5 pl-8">
          <label className="text-xl text-gray-500 mt-[3px] max-[300px]:hidden">
            Rate
          </label>
          <div className="flex items-center">
            {[...Array(5)].map((_, index) => {
              return (
                <button
                  key={index}
                  className="max-sm:ml-[3px]"
                  onClick={() => {
                    if (selectedStars === index + 1) {
                      setSelectedStars(0);
                    } else {
                      setSelectedStars(index + 1);
                    }
                  }}
                  onMouseOver={() => {
                    setHighlightedStars(index + 1);
                  }}
                  onMouseLeave={() => {
                    setHighlightedStars(0);
                  }}
                  type="button"
                >
                  <Star
                    width="max-sm:w-[1.4rem] w-[1.5rem]"
                    color={`${
                      index + 1 <= selectedStars
                        ? "fill-yellow-400"
                        : "fill-gray-500"
                    }  ${
                      index + 1 <= highlightedStars
                        ? "fill-yellow-400"
                        : "fill-gray-500"
                    }`}
                    marginLeft={"ml-[6px]"}
                  />
                </button>
              );
            })}
          </div>
        </div>
        <Textarea
          className="resize-none h-[20vh] border-t-[1px] rounded-none text-gray textarea text-base mt-5 pl-8 pt-3"
          placeholder="Add a review? You will not be able to edit this review once submitted."
          onChange={(event) => {
            setCurrentReviewCharacters(event.target.value);
          }}
          value={currentReviewCharacters}
          maxLength={500}
        />
        <div className="flex items-center justify-between w-[90%] mx-auto py-5 max-sm:flex-col">
          <p className="text-gray-500 text-sm">
            {500 - currentReviewCharacters.length} characters remaining
          </p>
          <Button
            variant={"lightBlue"}
            className="px-6 py-3 rounded-2xl max-[280px]:py-0 max-sm:mt-7"
            disabled={selectedStars && currentReviewCharacters ? false : true}
            onClick={() => {
              cookies.get("loggedInUserAccessToken") ? 
              axios
                .post(
                  `${domainName}/reviews/`,
                  {
                    show: showID,
                    user: cookies.get("userPK"),
                    show_slug: showName,
                    rating: selectedStars,
                    review_content: currentReviewCharacters,
                    category: "ALL"
                  },
                  {
                    headers: {
                      Authorization: `Bearer ${cookies.get(
                        "loggedInUserAccessToken"
                      )}`,
                    },
                  }
                )
                .then((response: any) => {
                  triggerDataFetching?.setTriggerDataFetching(
                    (fetch) => fetch + 1
                  );
                  showReviewModal?.setShowReviewModal(false);
                  setReviewModalIsClosed(true)
                  setCurrentUserIsSubmittedReview(true);
                })
                .catch((error: any) => {
                  console.error("There was an error!", error.response);
                }) : showReviewModal?.setShowReviewModal(false) || setModalState({ isOpen: true })
            }}
          >
            SAVE
          </Button>
        </div>
      </div>
      <div
        className="bg-black fixed top-0 left-0 right-0 bottom-0 opacity-60 z-20"
        onClick={() => {
          showReviewModal?.setShowReviewModal(false);
        }}
      ></div>
    </>
  );
}

export default ReviewFormModal;
