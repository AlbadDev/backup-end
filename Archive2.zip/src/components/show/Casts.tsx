import React from "react";
import Cast from "./Cast";
import "@/components/show/show-styles.css";
function Casts() {
  return (
    <div className="mx-auto w-[96vw] overflow-y-hidden">
      <div className="animate-show-casts">
        <p className="font-bold text-[#656565] mt-4 text-md max-sm:text-sm">
          CAST & CREW
        </p>
        <div className="w-full overflow-x-scroll casts-container pb-4 pt-1 flex">
          <Cast />
          {/* <Cast />
          <Cast />
          <Cast />
          <Cast />
          <Cast />
          <Cast />
          <Cast />
          <Cast />
          <Cast />
          <Cast />
          <Cast />
          <Cast />
          <Cast />
          <Cast />
          <Cast /> */}
        </div>
      </div>
    </div>
  );
}

export default Casts;
