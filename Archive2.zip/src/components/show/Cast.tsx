import Image from "next/image";
import React from "react";

function Cast() {
  return (
    <div className="shadow-md w-[8.6rem] max-[280px]:w-[6.4rem] max-sm:w-[6.9rem] max-[390px]:w-[7.3rem] flex-shrink-0 mx-2 rounded-md pb-2">
      <Image
        src={
          "/lula-headshot.jpg"
        }
        alt="LULA MEHBRAHTU"
        width={400}
        height={200}
        className="rounded-t-md"
      />
      <div className="ml-3 pt-1">
        <p className="font-bold text-[#656565] text-[0.8rem] max-[280px]:text-[0.7rem]">
          LULA MEHBRAHTU
        </p>
        <p className="text-[#656565] font-normal text-[0.7rem]">CAST</p>
      </div>
    </div>
  );
}

export default Cast;
