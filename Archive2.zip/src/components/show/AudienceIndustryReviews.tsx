"use client";
import React, { useContext, useEffect, useState } from "react";
import Review from "./Review";
import { domainName } from "../../../utilities/domainName";
import { Loader2 } from "lucide-react";
import TriggerDataFetchingContext from "../../../utilities/TriggerDataFetchingContext";
import { ShowAudienceOrIndustryReviewsContext } from "../show-detail-layout-context/ShowContext";
let reviews:
  | any[]
  | {
      id: string;
      reviewerName: string;
      rating: number;
      date: string;
      reviewerContent: string;
    }[] = [];

function AudienceIndustryReviews({ params }: { params: { showName: string } }) {
  const triggerDataFetching = useContext(TriggerDataFetchingContext);
  const [reviews, setReviews] = useState([]);
  const [noReviews, setNoReviews] = useState(false);
  const showAudienceOrIndustryReviews = useContext(ShowAudienceOrIndustryReviewsContext)
  const [noIndustryReviewsErrorMsg, setNoIndustryReviewsErrorMsg] = useState(false)
  useEffect(() => {
    function fetchReviews(showName: string) {
      fetch(`${domainName}/shows/${showName}/reviews/`, {
        cache: "no-store",
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Network response was not ok");
          }
          return response.json();
        })
        .then((data) => {
          if(showAudienceOrIndustryReviews?.showAudienceOrIndustryReviews === 'audience'){
            setNoIndustryReviewsErrorMsg(false)
            if (data.length === 0) {
              setNoReviews(true);
            } else {
              setNoReviews(false);
            }
            setReviews(data);

          }else{
            setNoIndustryReviewsErrorMsg(true)


          }
        })
        .catch((error) => {
          console.error("There was a problem with the fetch operation:", error);
        });
    }

    fetchReviews(params.showName);
  }, [triggerDataFetching?.triggerDataFetching, showAudienceOrIndustryReviews?.showAudienceOrIndustryReviews]);

if(noIndustryReviewsErrorMsg){
    return (<div className="pl-[5rem] min-h-[50vh]">
        <div className="w-[50vw] pt-10">
        <h1 className="font-bold text-xl">Coming Soon...</h1>
      <p>
Wondering what other platforms are saying about this show?
Read about what the Industry has to say about <span className="font-bold capitalize">{params.showName.replaceAll('-', ' ')}</span></p>
        </div>
    </div>)
  }
 
  if (noReviews) {
    return (
      <div className="pl-[5rem] min-h-[50vh]">
        <div className="w-[50vw] pt-10">
          <h1 className="font-bold text-xl">No Reviews Yet</h1>
          <p>
            Be the first to review{" "}
            <span className="font-bold capitalize">
              {params.showName.replaceAll("-", " ")}
            </span>{" "}
            and share your experience with others. Your review helps the show to
            improve and helps others make informed decisions.
          </p>
        </div>
      </div>
    );
  }

  if(noIndustryReviewsErrorMsg){
    return (<div className="pl-[5rem] min-h-[50vh]">
        <div className="w-[50vw] pt-10">
        <h1 className="font-bold">Coming Soon...</h1>{' '}
      <p>
Wondering what other platforms are saying about this show?
Read about what the Industry has to say about <span className="font-bold capitalize">{params.showName.replaceAll('-', ' ')}</span></p>
        </div>
    </div>)
  }
  return (
    <div className="pl-[10%] max-sm:pl-2 mb-9 max-md:pl-8 max-[360px]:px-3 min-h-[50vh]">
      {reviews?.length !== 0 ? (
        reviews?.map((review: any) => {
          return (
            <Review
              key={review.id}
              id={review.id}
              reviewerName={review.first_name}
              date={review.created_at}
              reviewContent={review.review_content}
              rating={review.rating}
              firstName={review.first_name}
              lastName={review.last_name}
            />
          );
        })
      ) : (
        <div>
          <Loader2 className="h-10 w-10 ml-[38vw] mt-[20vh] animate-spin" />
        </div>
      )}
    </div>
  );
}

export default AudienceIndustryReviews;