"use client";
import Star from "@/svgs/Star";
import { Dispatch, SetStateAction, useContext, useEffect, useRef, useState } from "react";
import { toast, Toaster } from "react-hot-toast";

import AudienceIndustryReviewsTab from "./AudienceIndustryReviewsTab";
import Casts from "./Casts";
import ReviewFormModal from "./ReviewFormModal";
import Clock from "@/svgs/Clock";
import CircleStar from "@/svgs/CircleStar";
import OptionsLines from "@/svgs/OptionsLines";
import CircularPlus from "@/svgs/CircularPlus";
import { domainName } from "../../../utilities/domainName";
import Cookies from "universal-cookie";
import {
  CurrentAuthUserIsSubmittedReviewContext,
  ShowCastsContext,
  ShowReviewModalContext,
} from "../show-detail-layout-context/ShowContext";
import Image from "next/image";
import { TokenAccessContext } from "@/lib/userTokenContext";
import { LoginModalContext } from "@/lib/loginModalContext";
import { createContext } from "vm";
import TriggerDataFetchingContext from "../../../utilities/TriggerDataFetchingContext";

function ShowDetail({ params, setReviewModalIsClosed }: { params: { showName: string }, setReviewModalIsClosed: Dispatch<SetStateAction<boolean>> }) {
  const cookies = new Cookies();
  const triggerDataFetching = useContext(TriggerDataFetchingContext);
  const showReviewModal = useContext(ShowReviewModalContext);
  const { modalState, setModalState } = useContext(LoginModalContext); //modal context
  const { userAccess, setUserAccess } = useContext(TokenAccessContext); //Acces Token context
  const currentAuthUserIsSubmittedReview = useContext(CurrentAuthUserIsSubmittedReviewContext)

  const showCasts = useContext(ShowCastsContext);
  const [reviewBtnHovered, setReviewBtnHovered] = useState(false);
  const [castsBtnHovered, setCastsBtnHovered] = useState(false);
  const [currentUserIsSubmittedReview, setCurrentUserIsSubmittedReview] =
  useState(false);


  const [readMore, setReadMore] = useState(false);
  const [show, setShow] = useState<{
    id: number;
    title: string;
    summary: string;
    slug: string;
    image: string;
    ratings_count: number;
    average_rating: number;
  }>({
    id: 0,
    title: "",
    summary: "",
    slug: "",
    image: "",
    ratings_count: 0,
    average_rating: 0,
  });
  useEffect(() => {
    if (currentUserIsSubmittedReview) {
      toast.success("Review submitted successfully!");
    }
  }, [showReviewModal?.showReviewModal]);
  useEffect(() => {
    function getShows() {
      fetch(`${domainName}/shows`, { cache: "no-store" })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Network response was not ok");
          }
          return response.json();
        })
        .then((data) => {
          const show = data.results.filter((show: any) => {
            return show.slug === params.showName;
          });
          setShow(show[0]);


        })
        .catch((error) => {
          console.error("There was a problem with the fetch operation:", error);
        });   
      
      
      
      }
      function getReviews() {
      fetch(`${domainName}/shows/${params.showName}/reviews/`, { cache: "no-store" })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Network response was not ok");
          }
          return response.json();
        })
        .then((data) => {
          const show = data.results.filter((show: any) => {
            return show.slug === params.showName;
          });
          setShow(show[0]);


        })
        .catch((error) => {
          console.error("There was a problem with the fetch operation:", error);
        });   
      
      
      
      }
        

    getShows();
    getReviews()
  }, [params.showName, triggerDataFetching?.triggerDataFetching]);
  return (
    <>
      <Toaster position="top-center" reverseOrder={false} />
      <Toaster
  position="top-center"
  reverseOrder={false}
/>

      <div className="relative">
        <div className="w-full h-[90vh] max-md:h-[75vh]">
          {
            show?.title === 'I AM - A Walking Universe' &&
            <Image
            fill
            // src={`${show.image}`}
            alt={show?.title}
            src={'/lula.jpg'}
            className="object-cover"
            />
          }
          {
            show?.title === 'I AM - One of many, many of One' &&

            <Image
            fill
            // src={`${show.image}`}
            alt={show?.title}
            src={'/lula2.jpg'}
            className="object-cover"
            />
          }
        </div>
        <div
          className="
            w-[65%] max-sm:pb-10 max-[374px]:pb-7 max-[360px]:pb-3 absolute bottom-[5%] left-[5%] z-10 max-md:w-[85%] max-sm:bottom-0"
        >
          <div
            onClick={() => {
              setReadMore((readMore) => !readMore);
            }}
            className={`mb-3 hide-scroll-bar
              max-md:active:bg-gray-500 max-md:active:opacity-50 transition-all
            ${
              readMore
                ? "max-[374px]:h-[7.68rem] max-[344px]:h-[7.5rem] max-md: max-sm:h-36 max-md:h-36 max-md:overflow-y-scroll"
                : ""
            }`}
          >
            <h1 className="max-sm:text-2xl text-gray-200 font-bold text-3xl max-md:text-3xl capitalize">
              {show?.title}
            </h1>
            <h2 className="text-gray-200 font-bold text-lg max-md:text-lg max-sm:text-base">
              Written by <span className="capitalize">Lula Mehbratu</span>
            </h2>
            <div>
              <p
                className={`text-gray-200 text-[1rem] max-sm:text-sm ${
                  readMore
                    ? ""
                    : "max-sm:line-clamp-3 max-md:line-clamp-1 max-[374px]:line-clamp-2 max-[344px]:line-clamp-1"
                }`}
              >
                {show?.summary}
              </p>
            </div>
          </div>
          <div className="flex items-center">
              
              <>
              <Clock />
              <p className="text-gray-200 ml-1 text-nowrap  max-sm:text-[0.8rem]">
                {show?.title === 'I AM - A Walking Universe' && '60mins'}
                {show?.title === 'I AM - One of many, many of One' && '20mins'}
              </p>
            </>
              
          </div>
          <div className="flex max-[360px]:w-[90%] max-lg:w-[28rem] w-[33rem] max-[280px]:w-full max-sm:w-[21rem] justify-between mt-[3.5%] max-[375px]:grid max-[360px]:grid-rows-2 max-[375px]:gap-5">
            <div className="w-[40%] max-sm:w-[48%] lg:w-[34%]">
              <div className="flex items-center justify-between max-md:w-full ">
                <div className="flex items-center max-[375px]:mr-3">
                  {[...Array(5)].map((_, index) => {
                    return (
                      <Star
                        width="w-[0.8rem]"
                        color={`${
                          index + 1 <= show?.average_rating
                            ? "fill-yellow-400"
                            : "fill-gray-300"
                        }`}
                        marginLeft="default"
                      />
                    );
                  })}
                </div>
                <p className="text-gray-200 font-bold max-sm:text-[0.9rem] max-[375px]:mr-3">
                  Audience
                </p>
                <p className="text-gray-200 font-bold max-sm:text-[0.9rem]">
                  {show?.ratings_count}
                </p>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center max-[375px]:mr-3">
                  {[...Array(5)].map((_, index) => {
                    return (
                      <Star
                        width="w-[0.8rem]"
                        color="fill-gray-300"
                        marginLeft="default"
                      />
                    );
                  })}
                </div>
                <p className="text-gray-200 font-bold -ml-2 max-sm:text-[0.9rem] max-[375px]:mr-3 max-[375px]:ml-0">
                  Industry
                </p>
                <p className="text-gray-200 font-bold max-sm:text-[0.9rem] max-[375px]:mr-3">
                  0
                </p>
              </div>
            </div>
            <div className="self-start max-lg:w-[30%] w-[22%] max-sm:w-[34%] flex justify-between lg:w-[23%]">
              <button
                className="max-[375px]:mr-3"
                onClick={() => {
        
                    if(currentAuthUserIsSubmittedReview?.currentAuthUserIsSubmittedReview){
                      showReviewModal?.setShowReviewModal(false)
                      setReviewModalIsClosed(true)
                      toast('You have already made a review', {
                              icon: '👏',
                            });

                    }else{
                      showReviewModal?.setShowReviewModal(true)
                      setReviewModalIsClosed(false)
                    }
                    // setModalState({ isOpen: true });
                }}
                onMouseOver={() => {
                  setReviewBtnHovered(true);
                }}
                onMouseLeave={() => {
                  setReviewBtnHovered(false);
                }}
                title="add a review"
              >
                <CircleStar
                  isClicked={`${
                    showReviewModal?.showReviewModal
                      ? "bg-gray-100 fill-black"
                      : "fill-gray-100 border-[1.5px] border-gray-100"
                  } ${
                    reviewBtnHovered
                      ? "bg-white fill-black"
                      : "fill-white border-[1.5px] border-gray-100"
                  }`}
                />
              </button>
              <button
                className="max-[375px]:mr-3"
                onClick={() => {
                  showCasts?.setShowCasts((showCasts) => !showCasts);
                }}
                onMouseOver={() => {
                  setCastsBtnHovered(true);
                }}
                onMouseLeave={() => {
                  setCastsBtnHovered(false);
                }}
                title="casts"
              >
                <OptionsLines
                  isClicked={`
                    ${
                      showCasts?.showCasts
                        ? "bg-gray-100 fill-black"
                        : "fill-gray-100 border-[1.5px] border-gray-100"
                    }

                    ${
                      castsBtnHovered
                        ? "bg-white fill-black "
                        : "fill-white border-[1.5px] border-gray-100"
                    }
                    `}
                />
              </button>
              <button title="add to watchlist">
                <CircularPlus />
              </button>
            </div>
          </div>
        </div>

        <AudienceIndustryReviewsTab />
        <div className="absolute top-0 bg-gradient-to-t from-black to-transparent left-0 right-0 bottom-0 opacity-100 z-0"></div>
      </div>
      {showCasts?.showCasts && <Casts />}
      {showReviewModal?.showReviewModal && (
        <ReviewFormModal
          showID={show.id}
          showName={params.showName}
          // showSlug={show.slug}
          setCurrentUserIsSubmittedReview={setCurrentUserIsSubmittedReview}
          setReviewModalIsClosed={setReviewModalIsClosed}
          
        />
      )}
    </>
  );
}

export default ShowDetail;
