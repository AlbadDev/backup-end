import React from "react";
import Star from "@/svgs/Star";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { formatDate } from "../../../utilities/fortmatDate";
import { truncateText } from "../../../utilities/truncateText";

function Review({
  id,
  reviewerName,
  date,
  reviewContent,
  rating,
  firstName,
  lastName,
}: {
  id: string;
  reviewerName: string;
  date: string;
  reviewContent: string;
  rating: number;
  firstName: string;
  lastName: string;
}) {
  return (
    <div className="w-[50%] mt-9 max-md:w-[85%] max-[360px]:w-full">
      <div className="flex max-[360px]:flex-col">
        <Avatar className="cursor-pointer w-[3rem] h-[3rem] max-[360px]:self-center">
          <AvatarImage src="https://github.com/shadcn.png" alt="profile pic" />
          <AvatarFallback className="p-2">CN</AvatarFallback>
        </Avatar>
        <div className="ml-6 max-md:ml-[1rem] max-[360px]:justify-between ">
          <div className="flex items-center max-[360px]:justify-center max-sm:w-[65%] max-[360px]:w-full max-md:w-[50%]">
            <p
              title={`${firstName} ${lastName}`}
              className="italic font-semibold text-[#00000080] text-[0.9rem] text-nowrap max-[360px]:text-xs"
            >
              {truncateText(firstName, 15)} {truncateText(lastName, 10)}
            </p>
            <div className="flex items-center mx-1">
              {[...Array(5)].map((_, index) => {
                return (
                  <Star
                    width="w-[0.9rem]"
                    color={`${
                      index + 1 <= rating ? "fill-yellow-400" : "fill-gray-300"
                    }`}
                    marginLeft="default"
                  />
                );
              })}
            </div>
            <p className="text-[#00000080] font-semibold text-[0.9rem] text-nowrap max-[360px]:text-xs">
              {formatDate(date).replaceAll("-", " ")}
            </p>
          </div>
          <p className="text-[0.9rem] mt-[2px] w-full">{reviewContent}</p>
        </div>
      </div>
    </div>
  );
}

export default Review;
