"use client";
import { Fragment, useContext } from "react";
import { Tab } from "@headlessui/react";
import { ShowAudienceOrIndustryReviewsContext } from "../show-detail-layout-context/ShowContext";
function AudienceIndustryReviewsTab() {
  const showAudienceOrIndustryReviews = useContext(ShowAudienceOrIndustryReviewsContext)

  return (
    <Tab.Group>
      <Tab.List className="max-[330px]:right-[40%] flex items-center ml-auto w-[35%] absolute -bottom-[1px] right-0 z-10 max-sm:right-[13%]">
        <Tab as={Fragment}>
          {({ selected }) => (
            <button
            onClick={() => {
              showAudienceOrIndustryReviews?.setShowAudienceOrIndustryReviews('audience')
            }}
              className={`
              ${selected ? "bg-white text-black" : "bg-transparent text-white"}
                max-md:mr-2
              px-8 py-2 rounded-t-lg font-bold outline-none max-md:px-2 max-md:py-1 max-md:text-sm
              max-md:
              `}
            >
              Audience
            </button>
          )}
        </Tab>
        <Tab as={Fragment}>
          {({ selected }) => (
            <button
             onClick={() => {
              showAudienceOrIndustryReviews?.setShowAudienceOrIndustryReviews('industry')
            }}
              className={`
              ${selected ? "bg-white text-black" : "bg-transparent text-white"}
                
              px-8 py-2 rounded-t-lg font-bold outline-none max-md:px-2 max-md:py-1 max-md:text-sm
              
              `}
            >
              Industry
            </button>
          )}
        </Tab>
      </Tab.List>
    </Tab.Group>
  );
}

export default AudienceIndustryReviewsTab;
