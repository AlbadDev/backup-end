import NextAuth from "next-auth/next";
// import {  NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import axios from "axios";
import Cookies from "universal-cookie";
// import Cookies from 'js-cookie'; // Import js-cookie for managing cookies



// export const authConfig = {

//   providers: [
//     GoogleProvider({
//       clientId: '341719446771-017uue501asl9a0p5u76bisdm95a0647.apps.googleusercontent.com',
//       clientSecret: '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',
//       profileUrl: 'https://www.googleapis.com/oauth2/v1/userinfo',
//       callbackUrl: 'http://localhost:3000/api/auth/callback/google',
//       accessTokenUrl: 'https://accounts.google.com/o/oauth2/token',
//       authorizationUrl: 'https://accounts.google.com/o/oauth2/auth', // Ensure this matches the URI in Google Developer Console
//     }),
//   ],
//   callbacks: 
//       {async jwt({ token, account }) {
//           // Persist the OAuth access_token to the token right after signin
//           if (account) {
//               token.accessToken = account.access_token;
//           }
//           return token;
//       },
//       async session({ session, token, user }) {
//         session.user.id = token.id;
//         session.accessToken = token.accessToken;
     

//         // const postData = {
//         //   email: session?.user?.email,
//         //   username: "GsmSalihou",
//         // }

//         // try {
//         //   const cookies = new Cookies();
//         //   const res = await axios.post("http://127.0.0.1:8000/getin/", postData)
          
//         // } catch (error) {
//         //   console.error('Error making Axios POST request:',error.message);
//         // }

//         return session;
//       }
//   },
//   secret: "process.env.SECRET",
//   pages: {
//     signIn: '/auth/signin',
//     error: '/auth/error/oommoo', // Error code passed in query string as ?error=
//   },
//   logger: {
//     error(code, ...message) {
//       console.error(code, ...message);
//     },
//     warn(code, ...message) {
//       console.warn(code, ...message);
//     },
//     debug(code, ...message) {
//       console.debug(code, ...message);
//     },
//   },
// }
//   // Add logger and other configurations as needed
// // };
// // export default (req, res) => NextAuth(req, res, authConfig);
// const handler = NextAuth(authConfig);

// export { handler as GET, handler as POST };

export const authConfig = {
  providers: [
    GoogleProvider({
      clientId: "341719446771-017uue501asl9a0p5u76bisdm95a0647.apps.googleusercontent.com",
      clientSecret: "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",
    }),
  ],
  secret: "process.env.NEXTAUTH_SECRET",
  nextauth_url:'http://localhost:3000',
 
  callbacks: {
    async jwt({ token, account }) {
      // Persist the OAuth access_token to the token right after signin
      if (account) {
        token.accessToken = account.access_token;
      }
      return token;
    },
    async session({ session, token, user }) {
      session.user.id = token.id;
      session.accessToken = token.accessToken;
      session.userToken;
      session.authen = token.user
      console.log("Data From Session : ",session.accessToken)
      const postData = {
        email: session?.user?.email,
        username: session?.user?.name,
      };

      return axios
        .post("http://127.0.0.1:8000/getin/", postData)
        .then((res) => {
          session.accessKey = res.data.access; // Set session.accessKey from API response
          session.user_pk = res.data.user_id
          console.log(res.data)
          return session;
        })
        .catch((error) => {
          console.error("Error making Axios POST request:", error.message);
          return session; // Return session object even if API call fails
        });

      // try {

      //   const res = await axios.post("http://127.0.0.1:8000/getin/", postData)

      //   // session.accessKey = res.data.access
      //   // session.user_pk = res.data.user_id

      //   // console.log("From Route :::",session.accessKey)
      // } catch (error) {
      //   console.error('Error making Axios POST request:',error.message);
      // }

      // return session;
    },
  },


  pages: {
    signIn: "/api/auth/signin",
    // signinUrl: '/api/auth/signin/google',
    error: "/auth/error", // Error code passed in query string as ?error=
    // callbackUrl: '/api/auth/callback/google'
  },
  logger: {
    error(code, ...message) {
      console.error(code, ...message);
    },
    warn(code, ...message) {
      console.warn(code, ...message);
    },
    debug(code, ...message) {
      console.debug(code, ...message);
    },
  },
};

const handler = NextAuth(authConfig);

export { handler as GET, handler as POST };

// session.userToken = res.data.access_token;
//             console.log(res.data.access_token,'Acess_Token',res.data.user_pk, "pk",session.userToken)
//             cookies.set("loggedInUserAccessToken", session.userToken, {
//               expires: new Date(Date.now() + 3600 * 1000 * 24),
//             });
//             cookies.set("pk", res.data.user_pk, {
//               expires: new Date(Date.now() + 3600 * 1000 * 24),
//             });

// clientId: '341719446771-017uue501asl9a0p5u76bisdm95a0647.apps.googleusercontent.com',
// clientSecret: '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',
