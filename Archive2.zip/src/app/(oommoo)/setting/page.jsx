'use client'
import { authConfig } from '@/app/api/auth/[...nextauth]/route';
import { getServerSession } from 'next-auth';
import { useSession } from 'next-auth/react';
import { useEffect } from 'react';
import Cookies from 'universal-cookie';
// import { authOptions } from '../api/auth/[...nextauth]';





export default  function SettingPage() {

  const { data: session, status } = useSession();

  const cookies = new Cookies();
  
  if (status === 'loading') {
    return <p>Loading...</p>;
  }

  if(status === 'authenticated') {
    
    cookies.set("loggedInUserAccessToken", session.accessKey, {
      expires: new Date(Date.now() + 3600 * 1000 * 24),
    })
    cookies.set("userPK", session.user_pk, {
      expires: new Date(Date.now() + 3600 * 1000 * 24),
    })

  }

  if (!session) {
    return <p>You need to be authenticated to view this page.</p>;
  }

  const { user } = session;
  // console.log(session)


 
  //   cookies.set("AccessToken", session.accessKey, {
  //     sameSite:'lax',
  //     expires: new Date(Date.now() + 3600 * 1000 * 24),
  //   })
  //   cookies.set("user", session.user_pk, {
  //     expires: new Date(Date.now() + 3600 * 1000 * 24),
  //   })

  

  // session.accessKey ? cookies.set("loggedInUserAccessToken", session.accessKey, {
  //   expires: new Date(Date.now() + 3600 * 1000 * 24),
  // }) : null

  // session.user_pk ? cookies.set("userPK", session.user_pk, {
  //   expires: new Date(Date.now() + 3600 * 1000 * 24),
  // }) : null

  console.log("one ", session.accessKey)

  return (
    <div>
      <p>Name: {user.name}</p>
      <p>Email: {user.email}</p>
      <p>Access: {session.accessToken}</p>
      <p>Token: {session.accessKey ? session.accessKey : 'loading...'}</p>
      <h4>User_Pk: {session.user_pk}</h4>
    </div>
  );
}

// import { getServerSession } from 'next-auth'
// import { getSession, useSession } from 'next-auth/react';
// import style from '../../../../styles/Setting.module.scss'
// import TableContent from '../../../components/user-profile/TabSection'


// const Setting =  () => {

//   const { data: session } = useSession();
 
//   console.log(session)

//   return (
//       <div className={style.container} >
//        <h3 style={{color:'#fff',backgroundColor:'black'}}>{session?.user?.email} hello</h3>
//         {/* <TableContent /> */}
//       </div>
//   );
// }

// export default Setting;


