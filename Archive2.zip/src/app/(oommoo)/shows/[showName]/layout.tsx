"use client";

import {
  ShowCastsContext,
  ShowReviewModalContext,
} from "@/components/show-detail-layout-context/ShowContext";
import { useState } from "react";

function Layout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [showCasts, setShowCasts] = useState(false);
  return (
    <ShowReviewModalContext.Provider
      value={{ showReviewModal, setShowReviewModal }}
    >
      <ShowCastsContext.Provider value={{ showCasts, setShowCasts }}>
        {children}
      </ShowCastsContext.Provider>
    </ShowReviewModalContext.Provider>
  );
}

export default Layout;
