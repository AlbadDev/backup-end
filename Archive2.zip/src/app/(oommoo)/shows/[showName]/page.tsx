"use client";
import AudienceIndustryReviews from "@/components/show/AudienceIndustryReviews";
import ShowDetail from "@/components/show/ShowDetail";
import { Dispatch, SetStateAction, createContext, useEffect, useState } from "react";
import TriggerDataFetchingContext from "../../../../../utilities/TriggerDataFetchingContext";
import { CurrentAuthUserIsSubmittedReviewContext, ShowAudienceOrIndustryReviewsContext } from "@/components/show-detail-layout-context/ShowContext";
import { domainName } from "../../../../../utilities/domainName";
import { Review } from "../../../../../utilities/types";
import Cookies from "universal-cookie";

function Show({ params }: { params: { showName: string } }) {
  const cookies = new Cookies();
  const currentAuthUserPK = cookies.get('userPK')
  const [triggerDataFetching, setTriggerDataFetching] = useState(0);
  const [showAudienceOrIndustryReviews, setShowAudienceOrIndustryReviews] = useState('audience')
  const [currentAuthUserIsSubmittedReview, setCurrentAuthUserIsSubmittedReview] = useState(false)
  const [reviewModalIsClosed, setReviewModalIsClosed] = useState(false)
  useEffect(() => {
    function fetchReviews(showName: string) {
      fetch(`${domainName}/shows/${showName}/reviews/`, {
        cache: "no-store",
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Network response was not ok");
          }
          return response.json();
        })
        .then((data) => {
          data.map((review: Review) => {
            //if user is authenticated
            if(currentAuthUserPK){
              //if user has done a review
              if(currentAuthUserPK === review.user_id){
                setCurrentAuthUserIsSubmittedReview(true)
              }else{
                setCurrentAuthUserIsSubmittedReview(false)
              }
            }else{
                setCurrentAuthUserIsSubmittedReview(false)
            }

            // if(currentAuthUserPK){
            // //@ts-ignore
            //   if(reviewersIDs.includes(currentAuthUserPK)){
            //     setCurrentAuthUserIsSubmittedReview(true)

            //   }else{
            //     setCurrentAuthUserIsSubmittedReview(false)
            //   }
            // }
            // if(currentAuthUserPK === review.user_id){
            //   setCurrentAuthUserIsSubmittedReview(true)
            // }else{
            //   setCurrentAuthUserIsSubmittedReview(false)
            // }
           
           
          })
        })
        .catch((error) => {
          console.error("There was a problem with the fetch operation:", error);
        });
    }
    fetchReviews(params.showName)
  }, [showAudienceOrIndustryReviews, reviewModalIsClosed])



  return (
    <main className="bg-white">
      <CurrentAuthUserIsSubmittedReviewContext.Provider value={{currentAuthUserIsSubmittedReview, setCurrentAuthUserIsSubmittedReview}}>
      <ShowAudienceOrIndustryReviewsContext.Provider value={{showAudienceOrIndustryReviews, setShowAudienceOrIndustryReviews}}>
        <TriggerDataFetchingContext.Provider
          value={{ triggerDataFetching, setTriggerDataFetching }}
          >
          <ShowDetail params={params} setReviewModalIsClosed={setReviewModalIsClosed}/>
          <div>
            <AudienceIndustryReviews params={params} />
          </div>
        </TriggerDataFetchingContext.Provider>
        </ShowAudienceOrIndustryReviewsContext.Provider>
        </CurrentAuthUserIsSubmittedReviewContext.Provider>
    </main>
  );
}

export default Show;
