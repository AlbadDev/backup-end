"use client"
import Show from "@/components/home-page/Show";
import { Dispatch, SetStateAction, useContext, useEffect, useState } from "react";
import { domainName } from "../../../utilities/domainName";
import TokenContextProvider, { TokenAccessContext } from '../../lib/userTokenContext'
import { Loader2 } from "lucide-react";

function getShows(setShows: Dispatch<SetStateAction<never[] | any[]>>) {
  fetch(`${domainName}/shows/`, {
    cache: "no-store",
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    return response.json(); 
  })
  .then(data => {
    setShows(data.results)
  })
  .catch(error => {
    console.error('Fetch error:', error);
  });

}

const Home = () => {
  const [shows, setShows] = useState<never[] | any[]>([])
  useEffect(() => {

    getShows(setShows)
  }, [])


  const { userAccess, setUserAccess } = useContext(TokenAccessContext);

 const lulaImages = [
    {image: '/lula2.jpg',},
    {image: '/lula.jpg',}
  ]
  if(shows.length === 0){
    return(
      <main className="bg-[#1A1A1A] max-md:bg-black min-h-[100vh]">
        <div className="max-md:pt-[7rem] flex flex-wrap pt-[8rem] items-center w-[92vw] mx-auto"> 
            <Loader2 className="h-[80px] w-[80px] animate-spin text-gray-300 mx-auto mt-[20vh]" />
      </div>
      </main>
    )
  }
  return (
    <main className="bg-[#1A1A1A] max-md:bg-black min-h-[100vh]">
      <div className="max-md:pt-[7rem] flex flex-wrap pt-[8rem] items-center w-[92vw] mx-auto">        
        {shows?.map((show: any, index) => {
          return (

            <Show
              id={show.id}
              title={show.title}
              summary={show.summary}
              image={lulaImages[index].image}
              ratingsCount={show.ratings_count}
              averageRatings={show.average_rating}
              // thumbnailUrl={show.eventThumbnailUrl}
              // numberOfReviews={show.numberOfReviews}
              // typeOfEvent={show.typeOfEvent}
              slug={show.slug}
              key={show.id}
            />

          );
        })}
      </div>
    </main>
  );
}
export default Home
