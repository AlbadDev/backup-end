"use client"
import { GoogleOAuthProvider } from '@react-oauth/google';

import Footer from "@/components/root-layout/Footer";
import "./globals.css";
import HeaderAndAuthModal from "@/components/root-layout/HeaderAndAuthModal";
import Head from "next/head";
import TokenContextProvider from "@/lib/userTokenContext";
import ModalContextProvider from "@/lib/loginModalContext";
import UserContextProvider from "@/lib/ContextApi/UserContext";
import { QueryClient, QueryClientProvider } from "react-query";
import { SessionProvider } from 'next-auth/react';
import { getServerSession } from 'next-auth';
import { authConfig } from '../api/auth/[...nextauth]/route';

const queryClient = new QueryClient();

export default function RootLayout({
  children,session
}: Readonly<{
  children: React.ReactNode;
  session:any
}>) {
  return (
    <html lang="en">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body className="relative flex flex-col justify-between min-h-[100vh]">
      
        <TokenContextProvider>
          <UserContextProvider>
            <ModalContextProvider>
              <QueryClientProvider client={queryClient}>
                <SessionProvider session={session}   >
                  <HeaderAndAuthModal>{children}</HeaderAndAuthModal>
               </SessionProvider>
              </QueryClientProvider>
            </ModalContextProvider>
          </UserContextProvider>
        </TokenContextProvider>

        <Footer />
       
      </body>
    </html>
  );
}
