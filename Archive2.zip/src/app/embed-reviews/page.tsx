import { Textarea } from "@/components/ui/textarea";
import OommooLogo from "@/svgs/OommooLogo";
import Star from "@/svgs/Star";
import "@/app/embed-reviews/embed-reviews-styles.css";
import { Button } from "@/components/ui/button";
import ReviewForm from "@/components/embed-reviews-page/ReviewForm";

let reviews = [
  {
    id: 0,
    reviewerName: "Zaira Rasool",
    dateOfReview: "2024",
    reviewContent:
      "The show was absolutely incredible. I loved the part where Badara become rich and decided to purchase Africell Gambia ltd. Its really a fun show.",
    rating: 4,
  },
  {
    id: 1,
    reviewerName: "Sulayman Kendor",
    dateOfReview: "2024",

    reviewContent:
      "I think the part that shows the actual ways to earn your first million dollars hits me a lot and I can spend extra 100 bucks just to learn this strategy.",
    rating: 3,
  },
  {
    id: 2,
    reviewerName: "Ebrima Barry",
    dateOfReview: "2022",
    reviewContent:
      "I didn’t like the fact that it took many years for Badara to be actually rich.... Hes a hustler and works very hard with smartness and intelligence.",
    rating: 3,
  },
  {
    id: 3,
    reviewerName: "Bugzy Malone",
    dateOfReview: "2023",
    reviewContent:
      "The show was absolutely incredible. I loved the part where Badara become rich and decided to purchase Africell Gambia ltd. Its really a fun show.",
    rating: 4,
  },
  {
    id: 4,
    reviewerName: "Sulayman Kendor",
    dateOfReview: "2024",
    reviewContent:
      "I think the part that shows the actual ways to earn your first million dollars hits me a lot and I can spend extra 100 bucks just to learn this strategy.",
    rating: 2,
  },
  {
    id: 5,
    reviewerName: "Ebrima Barry",
    dateOfReview: "2022",
    reviewContent:
      "I didn’t like the fact that it took many years for Badara to be actually rich.... Hes a hustler and works very hard with smartness and intelligence.",
    rating: 1,
  },
];

function EmbedReviews() {
  return (
    <>
      <header className="border-b-[5px] border-white p-9 flex items-center">
        <div>
          <OommooLogo />
          <p className="font-medium text-white text-[1.8vh] italic w-[13.5vw] ml-1">
            One of many. many of One
          </p>
        </div>
        <p className="text-white text-xl font-bold ml-5">Show Reviews</p>
      </header>
      <main className="mb-8">
        <section className="border-b-[1px] border-gray-400 py-6">
          <div className="w-[70%] pl-6">
            <h1 className="text-white font-bold text-[22px]">
              I Am A Walking Universe
            </h1>
            <ReviewForm />
          </div>
        </section>
        <section>
          {reviews.map((review) => {
            return (
              <div
                key={review.id}
                className="border-b-[1px] border-gray-400 pl-5 pb-4 pt-4"
              >
                <h1 className="text-white font-bold text-lg">
                  {`${review.reviewerName} in ${review.dateOfReview}`}
                </h1>
                <p className="text-white font-medium text-[15px] w-[79%] mt-1">
                  {review.reviewContent}
                </p>
                <div className="flex items-center mt-2">
                  {[...Array(5)].map((_, index) => {
                    return (
                      <Star
                        key={index}
                        width="w-[14px]"
                        color={`${
                          index + 1 <= review.rating
                            ? "fill-[#F6C20A]"
                            : "fill-gray-300"
                        }`}
                        marginLeft="ml-1"
                      />
                    );
                  })}
                  <p className="text-white ml-3 text-[15px]">
                    {review.rating}/5
                  </p>
                </div>
              </div>
            );
          })}
        </section>
      </main>
    </>
  );
}

export default EmbedReviews;
