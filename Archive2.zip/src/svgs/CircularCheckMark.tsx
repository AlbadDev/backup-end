import { Dispatch, SetStateAction } from "react";

function CircularCheckMark({
  currentHighlightedAccount,
  checkMarkAccountType,
}: {
  currentHighlightedAccount: string;
  checkMarkAccountType: string;
}) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 512 512"
      className={`${
        currentHighlightedAccount === checkMarkAccountType
          ? "fill-gray-700"
          : "fill-white bg-gray-600 border-[1px] border-gray-600"
      } rounded-full w-7 h-7 transition-all mt-4 max-sm:mt-5 max-[500px]:mt-[16.5px] max-sm:w-6 max-sm:h-6`}
    >
      <path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z" />
    </svg>
  );
}

export default CircularCheckMark;