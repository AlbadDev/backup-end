import { NextRequest, NextResponse } from "next/server";

export function middleware(req: NextRequest, res: NextResponse) {
  const currentUser = req.cookies.has("loggedInUserAccessToken");
  // Block access to the login page if the user is already logged in
  if (!currentUser && req.nextUrl.pathname === "/profile") {
    return Response.redirect(new URL("/", req.url));
  }

  if (currentUser && req.nextUrl.pathname.startsWith("/login")) {
    return Response.redirect(new URL("/", req.url));
  }

  // if (currentUser && req.nextUrl.pathname.startsWith('/register') ) {
  //     return Response.redirect(new URL('/profile', req.url))
  // }

  // if (currentUser && req.nextUrl.pathname === '/' ) {
  //     return Response.redirect(new URL('/profile', req.url))
  // }

  // if (publicPaths.some(path => request.nextUrl.pathname.startsWith(path))) {
  //     return; // Allow access to public paths
  // }
}

// try {
//     // Example logic that might throw an error
//     if (!req.cookies.has('loggedInUserAccessToken')) {
//         throw new Error('Unauthorized: User is not authenticated');
//     }

//     // Continue with the request if authenticated
//     return NextResponse.next();
// } catch (error) {
//     console.error('Error in middleware:', error.message);
//     return NextResponse.error(new Error('Unauthorized access')); // Example of returning an error response
// }

// import { NextRequest, NextResponse } from 'next/server';
// // import Cookies  from 'universal-cookie'
// import Cookies from 'js-cookie';

// export async function middleware(req: NextRequest, res: NextResponse) {
//     // const cookies = new Cookies();
//     // import Cookies from 'js-cookie';
//     if(req.cookies.has('loggedInUserAccessToken')){
//         return
//     } else {
//         return NextResponse.redirect(new URL('/shows', req.url));
//     }

// }
